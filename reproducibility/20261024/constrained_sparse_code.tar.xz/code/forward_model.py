"""Deterministic standalone CFF reconstruction and instrumented FreeType rasterization.
This is a master-outline reconstruction, not the official font's full build pipeline.
"""
from __future__ import annotations
import io, math, hashlib
import numpy as np
import freetype
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.pointPen import PointToSegmentPen
from fontTools.pens.t2CharStringPen import T2CharStringPen

CANVAS=(768,768)
ORIGIN=(128.125,600.375)

def compile_master(ref: dict, displacement=None) -> bytes:
    n=len(ref['nodes']);delta=np.zeros((n,2)) if displacement is None else np.asarray(displacement,float)
    if delta.shape!=(n,2) or not np.isfinite(delta).all():raise ValueError('Invalid coordinates')
    pen=T2CharStringPen(ref['width'],None,roundTolerance=0);points=PointToSegmentPen(pen)
    for contour in ref['contours']:
        points.beginPath()
        for j in contour:
            r=ref['nodes'][j];kind=None if r['type']=='o' else ('curve' if r['type'].startswith('c') else 'line')
            points.addPoint((r['x']+delta[j,0],r['y']+delta[j,1]),segmentType=kind,smooth=r['type'].endswith('s'))
        points.endPath()
    empty=T2CharStringPen(500,None).getCharString();fb=FontBuilder(ref['units_per_em'],isTTF=False)
    fb.setupGlyphOrder(['.notdef','observed']);fb.setupCharacterMap({0x0EAD:'observed'})
    fb.setupHorizontalMetrics({'.notdef':(500,0),'observed':(round(ref['width']),0)})
    fb.setupHorizontalHeader(ascent=1000,descent=-300)
    fb.setupNameTable({'familyName':'Private research master reconstruction','styleName':'Regular','uniqueFontIdentifier':'CG-Lao-event','fullName':'Private research master reconstruction','psName':'CGLaoEvent'})
    fb.setupOS2(sTypoAscender=1000,sTypoDescender=-300,usWinAscent=1000,usWinDescent=300);fb.setupPost()
    fb.setupCFF('CGLaoEvent',{'FullName':'Private research master reconstruction','FamilyName':'Private research master reconstruction','Weight':'Regular'}, {'.notdef':empty,'observed':pen.getCharString()}, {})
    fb.font.recalcTimestamp=False;fb.font['head'].created=2082844800;fb.font['head'].modified=2082844800
    out=io.BytesIO();fb.save(out);return out.getvalue()

def render(data: bytes, ppem: int, origin=ORIGIN):
    face=freetype.Face(io.BytesIO(data));face.set_pixel_sizes(0,ppem)
    xy=np.rint(np.array(origin)*64).astype(int);xi,yi=math.floor(xy[0]/64),math.floor(xy[1]/64)
    face.set_transform(freetype.Matrix(65536,0,0,65536),freetype.Vector(int(xy[0]-xi*64),int(yi*64-xy[1])))
    flags=freetype.FT_LOAD_RENDER|freetype.FT_LOAD_NO_BITMAP|freetype.FT_LOAD_NO_HINTING|freetype.FT_LOAD_NO_AUTOHINT
    face.load_glyph(1,flags);bitmap=face.glyph.bitmap
    if bitmap.pixel_mode!=freetype.FT_PIXEL_MODE_GRAY:raise ValueError('Not grayscale')
    raw=np.array(bitmap.buffer,dtype=np.uint8).reshape(bitmap.rows,abs(bitmap.pitch))[:,:bitmap.width]
    if bitmap.pitch<0:raw=raw[::-1]
    left,top=xi+face.glyph.bitmap_left,yi-face.glyph.bitmap_top
    h,w=CANVAS
    if min(left,top)<0 or left+bitmap.width>w or top+bitmap.rows>h:raise ValueError('Clipping')
    image=np.full(CANVAS,255,np.uint8);image[top:top+bitmap.rows,left:left+bitmap.width]=255-raw
    return image,{'ppem':ppem,'origin_px':list(origin),'origin_26_6':xy.tolist(),'bitmap_origin':[left,top],
                  'bitmap_size':[bitmap.width,bitmap.rows],'load_flags':flags,'freetype':list(freetype.version()),
                  'image_sha256':hashlib.sha256(image.tobytes()).hexdigest(),'clipping':False}
