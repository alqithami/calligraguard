from pathlib import Path
import json,hashlib,sys
import numpy as np
from source_io import digest,source_difference
from forward_model import compile_master,render
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def main():
 p=ROOT/'private_artifacts';before=json.loads((p/'before.json').read_text());after=json.loads((p/'after.json').read_text())
 assert digest(before)=='fb7834b0fb0ef84c6dcd46cee37eefad9afe438929b9cce372f0e3c2f2258354'
 assert digest(after)=='635b4c5a500074bf8bb0ae6eb1e2f245aef37d0d84173e82ca1c1694121c1efb'
 inputs=p/'inference';inputs.mkdir(exist_ok=False);evaluation=p/'evaluation_only';evaluation.mkdir(exist_ok=False)
 old=json.loads((ROOT/'upstream_original/results/CAPTURE_RECEIPTS.json').read_text());old={(r['master'],r['ppem']):r for r in old}
 records=[];replays=0
 for i,(a,b) in enumerate(zip(before,after),1):
  ref=inputs/f'master_{i}.json';put(ref,b)
  data=[];normal=[]
  for size in [192,384]:
   q,t=render(compile_master(a),size);r,rt=render(compile_master(b),size)
   assert t['image_sha256']==old[(i,size)]['candidate']['image_sha256']
   assert rt['image_sha256']==old[(i,size)]['reference']['image_sha256'];replays+=2
   data.append(q);normal.append(r)
  imagefile=inputs/f'master_{i}.npz';np.savez_compressed(imagefile,images=np.stack(data))
  d=np.array([[u['x']-v['x'],u['y']-v['y']] for u,v in zip(a['nodes'],b['nodes'])])
  put(evaluation/f'master_{i}.json',{'before':a,'changed_nodes':source_difference(a,b),'true_displacement':d.tolist()})
  records.append({'master':i,'reference':ref.name,'images':imagefile.name,'reference_sha256':sha(ref),'images_sha256':sha(imagefile),'image_array_hashes':[hashlib.sha256(q.tobytes()).hexdigest() for q in data]})
 put(p/'INFERENCE_MANIFEST.json',records)
 put(ROOT/'provenance/PREPARATION_VERIFIED.json',{'status':'full_source_geometry_and_original_fit_images_match','masters':6,'fitting_capture_images_replayed':replays,'canonical_geometry_sha256':{'before':digest(before),'after':digest(after)},'manifest_sha256':sha(p/'INFERENCE_MANIFEST.json'),'candidate_source_not_passed_to_solver':True,'note':'Raw upstream bytes verified on authorized Mac; canonical geometry transferred and independently rehashed here.'})
 print('PREPARATION_VERIFIED',replays)
if __name__=='__main__':main()
