"""Portable repeat of the four numerical arms in a NEW output directory.
Downloads public source bytes privately, verifies pins, uses the frozen solver.
Does not run or modify any IBM service. Does not overwrite existing results.
"""
from __future__ import annotations
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import argparse,concurrent.futures,json,hashlib,datetime
import numpy as np
from acquire_lao_sources import acquire
from forward_model import compile_master,render
from budgeted_solver import infer,CONFIG
from resume_gate import normalize
ROOT=Path(__file__).resolve().parents[1]

def put(p,v):Path(p).write_text(json.dumps(normalize(v),indent=2,allow_nan=False)+'\n')
def one(t):
 number,ref,queries,method,freeze,out=t
 result=infer(ref,queries,method,freeze,CONFIG['render_call_cap']);result['master']=number
 p=Path(out)/f'm{number}_freeze{freeze}_{method}.json';put(p,result)
 return p.name

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--output',type=Path,required=True);parser.add_argument('--workers',type=int,default=4);args=parser.parse_args()
 if not 1<=args.workers<=8:raise ValueError('workers must be between 1 and 8')
 output=args.output.resolve();output.mkdir(parents=True,exist_ok=False);private=output/'private_sources'
 source_receipts=acquire(private);before=json.loads((private/'before.json').read_text());after=json.loads((private/'after.json').read_text())
 old=json.loads((ROOT/'upstream_original/results/CAPTURE_RECEIPTS.json').read_text());receipts={(r['master'],r['ppem']):r for r in old}
 (output/'outputs').mkdir();tasks=[]
 for i,(a,b) in enumerate(zip(before,after),1):
  q=[]
  for size in CONFIG['fit_ppem']:
   image,meta=render(compile_master(a),size)
   if meta['image_sha256']!=receipts[(i,size)]['candidate']['image_sha256']:
    raise RuntimeError('Environment changed the pinned rendering; do not silently compare')
   q.append(image)
  for freeze in [1,4]:
   for method in CONFIG['methods']:tasks.append((i,b,q,method,freeze,str(output/'outputs')))
 put(output/'PROTOCOL.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'settings':CONFIG,'source_receipts':source_receipts,
 'solver_sha256':hashlib.sha256((ROOT/'code/budgeted_solver.py').read_bytes()).hexdigest(),'expected_outputs':48})
 with concurrent.futures.ProcessPoolExecutor(max_workers=args.workers) as pool:
  for n,future in enumerate(concurrent.futures.as_completed([pool.submit(one,t) for t in tasks]),1):print(n,future.result(),flush=True)
 allresults=[json.loads(p.read_text()) for p in sorted((output/'outputs').glob('*.json'))];assert len(allresults)==48
 hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (output/'outputs').glob('*.json')};put(output/'INFERENCE_SEALED.json',hashes)
 # No public claims are produced automatically. The archived replay verifier and
 # full evaluated results are supplied alongside this repeat-inference utility.
 put(output/'COMPLETE.json',{'status':'repeat_inference_complete','outputs':48,'scope':'repeat inference only; separately audit/evaluate results before publication'})
 print('REPRODUCTION_INFERENCE_COMPLETE')
if __name__=='__main__':main()
