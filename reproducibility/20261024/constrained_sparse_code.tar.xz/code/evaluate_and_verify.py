"""Saved-output replay audit. No optimizer entry point is called.
Uses original compiler/FreeType; this is not an independent rasterizer.
"""
from pathlib import Path
import json,hashlib,datetime,sys,math
import numpy as np
from forward_model import compile_master,render,ORIGIN
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def rank_again(ref,q,base):
 scores=[0.]*len(ref['nodes'])
 for size,a,b in zip([192,384],q,base):
  delta=a.astype(np.int16)-b.astype(np.int16);yy,xx=np.where(delta!=0)
  points=np.array([[n['x']*size/ref['units_per_em']+ORIGIN[0],ORIGIN[1]-n['y']*size/ref['units_per_em']] for n in ref['nodes']])
  for y,x in zip(yy,xx):
   distances=(points[:,0]-x-.5)**2+(points[:,1]-y-.5)**2;j=int(np.argmin(distances));scores[j]+=abs(int(delta[y,x]))
 return sorted(range(len(scores)),key=lambda i:(-scores[i],i))
def metrics(q,p,base):
 d=q.astype(np.int16)-p.astype(np.int16);n=q.astype(np.int16)-base.astype(np.int16)
 sse=int(np.sum(d.astype(np.int64)**2));den=int(np.sum(n.astype(np.int64)**2));maximum=int(np.max(np.abs(d)))
 return {'sse':sse,'null_sse':den,'ratio':sse/den if den else None,'max_gray_error':maximum,'image_sha256':hashlib.sha256(p.tobytes()).hexdigest()}
def main():
 out=ROOT/'results';complete=json.loads((out/'INFERENCE_COMPLETE.json').read_text());sealed=json.loads((out/'INFERENCE_SEALED.json').read_text())['sha256'];lock=json.loads((out/'PROTOCOL_LOCK.json').read_text())
 assert len(sealed)==48 and complete['outputs']==48
 for n,h in sealed.items():assert sha(out/'outputs'/n)==h
 for n,h in lock['source_sha256'].items():assert sha(ROOT/n)==h
 for n,h in lock['original_file_sha256'].items():assert sha(ROOT/'upstream_original'/n)==h
 manifest=json.loads((ROOT/'private_artifacts/INFERENCE_MANIFEST.json').read_text())
 records=[];counts={'outputs':0,'source_captures':0,'prediction_images':0,'fit_metric_checks':0,'frozen_source_checks':0,'full_coordinate_sweeps':0,'historical_baseline_prediction_images':0}
 for entry in manifest:
  i=entry['master'];ref=json.loads((ROOT/'private_artifacts/inference'/entry['reference']).read_text());truth=json.loads((ROOT/'private_artifacts/evaluation_only'/f'master_{i}.json').read_text())
  with np.load(ROOT/'private_artifacts/inference'/entry['images'],allow_pickle=False) as z:qfit=z['images'].copy()
  ref_font=compile_master(ref);actual_font=compile_master(truth['before']);qs={};bases={}
  for ppem in [192,384,256,512]:
   qs[ppem]=render(actual_font,ppem)[0];bases[ppem]=render(ref_font,ppem)[0];counts['source_captures']+=2
  assert all(np.array_equal(q,qs[size]) for q,size in zip(qfit,[192,384]))
  nearest=rank_again(ref,list(qfit),[bases[192],bases[384]])
  for freeze in [1,4]:
   historical=json.loads((ROOT/f'upstream_original/results/master_{i}/without_nearest_top{freeze}.json').read_text())
   assert historical['frozen_nodes']==([] if historical['null_compatible'] else nearest[:freeze])
   priorfont=compile_master(ref,np.array(historical['source_displacements']))
   prior=[]
   for size,v in zip([192,384],historical['fit_views']):
    mm=metrics(qs[size],render(priorfont,size)[0],bases[size]);counts['historical_baseline_prediction_images']+=1
    assert mm['sse']==v['squared_error'] and mm['max_gray_error']==v['max_absolute_gray_error']
    prior.append(mm)
   for method in lock['settings']['methods']:
    name=f'm{i}_freeze{freeze}_{method}.json';r=json.loads((out/'outputs'/name).read_text());d=np.array(r['source_displacements'])
    assert r['master']==i and r['method']==method and r['frozen_nodes']==nearest[:freeze]
    assert d.shape==(44,2) and np.isfinite(d).all() and np.max(abs(d))<=200+1e-10
    assert not np.any(d[r['frozen_nodes']]);counts['frozen_source_checks']+=1
    assert r['render_calls']<=8000 and r['render_calls']==2*r['font_builds'] and not r['necessity_certified']
    support=set(r['selected_nodes']);moved=set(np.flatnonzero(np.linalg.norm(d,axis=1)>.5).tolist())
    assert not np.any(d[[j for j in range(44) if j not in support]])
    if 'sparse4' in method:assert len(support)<=4
    if 'sparse8' in method or 'multistart' in method:assert len(support)<=8
    for trace in r['trace']:
     if trace['phase']=='complete_coordinate_sweep':
      n=len(next(s['support'] for s in r['starts_scheduled'] if s['name']==trace['start']))
      assert trace['directional_trials']==4*n and trace['coordinates_tested']==2*n
      counts['full_coordinate_sweeps']+=1
    font=compile_master(ref,d);views=[]
    for ppem in [192,384,256,512]:
     m=metrics(qs[ppem],render(font,ppem)[0],bases[ppem]);m['ppem']=ppem;views.append(m);counts['prediction_images']+=1
    for observed,reported in zip(views[:2],r['fit_views']):
     for key in ['sse','null_sse','ratio','max_gray_error']:
      assert observed[key]==reported[key],(name,key,observed[key],reported[key]);counts['fit_metric_checks']+=1
    strict=all(v['max_gray_error']<=1 for v in views[:2]);approx=all(v['ratio'] is not None and v['ratio']<=.05 for v in views[:2])
    assert strict==r['strict_fit'] and approx==r['approximate_fit']
    changed=bool(truth['changed_nodes']);null=all(np.max(abs(qs[z].astype(int)-bases[z].astype(int)))<=1 for z in [192,384])
    if null:assert r['status']=='unchanged_source_compatible' and not d.any()
    else:
     expected='strict_counterexample_found' if strict else 'approximate_counterexample_only' if approx else 'no_counterexample_found_necessity_unknown'
     assert r['status']==expected
    records.append({'master':i,'freeze':freeze,'method':method,'changed_master':changed,'frozen_nodes':r['frozen_nodes'],
      'strict_fit':strict,'approximate_fit':approx,'null_compatible':null,'status':r['status'],
      'worst_fit_sse_ratio':max(v['ratio'] for v in views[:2]) if changed else None,
      'check_worst_sse_ratio':max(v['ratio'] for v in views[2:]) if changed else None,
      'strict_check':all(v['max_gray_error']<=1 for v in views[2:]),
      'known_feasible_regression_case':i in [5,6] and freeze==1,
      'historical_strict_result':historical['strict_fit_match'],'historical_approximate_result':historical['approximate_fit_match'],
      'selected_node_count':len(support),'moved_nodes':sorted(moved),'exact_historical_moved_support':moved==set(truth['changed_nodes']),
      'render_calls':r['render_calls'],'seconds':r['seconds'],'views':views})
    counts['outputs']+=1
 summary=[]
 for method in lock['settings']['methods']:
  rows=[r for r in records if r['method']==method];changed=[r for r in rows if r['changed_master']];known=[r for r in rows if r['known_feasible_regression_case']]
  summary.append({'method':method,'altered_searches':len(changed),'strict_counterexamples':sum(r['strict_fit'] for r in changed),
   'approximate_counterexamples_including_strict':sum(r['approximate_fit'] for r in changed),
   'known_feasible_strict_recovered':sum(r['strict_fit'] for r in known),'known_feasible_approximate_recovered':sum(r['approximate_fit'] for r in known),
   'normal_controls':len(rows)-len(changed),'normal_controls_retained':sum(r['null_compatible'] for r in rows if not r['changed_master']),
   'altered_render_calls':sum(r['render_calls'] for r in changed),'accumulated_altered_seconds':sum(r['seconds'] for r in changed)})
 report={'status':'matched_constrained_solver_gate_complete','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'independent_repair_events':1,
  'master_count':6,'outputs':48,'source_byte_verification':'full upstream blobs verified on Mac; transferred canonical geometry rehashed and original fit images matched',
  'counts':counts,'summary':summary,'records':records,'recovery_phase_seconds':complete['seconds'],'wall_time_scope':complete.get('seconds_scope','initial run'),'total_elapsed_since_protocol_seconds':(datetime.datetime.fromisoformat(complete['utc'])-datetime.datetime.fromisoformat(lock['declared_utc'])).total_seconds(),
  'limits':['Lao development regression only; two known-feasible cases already exposed','one event, not six independent faults','standalone unhinted CFF master reconstructions','same compiler and FreeType replay','no repeated timing benchmark','current arms share new full-view minimax acceptance during refinement; archived original is a historical reference not an isolated initialization ablation','same maximum render ceiling does not imply equal realized work','reporting recovery repeated 24 unsaved searches; per-output render counts/timings exclude discarded first-attempt work','no failed local search proves source necessity','no source binary from user IBM server accessed or changed']}
 for n,h in sealed.items():assert sha(out/'outputs'/n)==h
 put(out/'RESULTS.json',report)
 receipt={'status':report['status'],'verified_utc':report['verified_utc'],'counts':counts,'summary':summary,'results_sha256':sha(out/'RESULTS.json'),'sealed_sha256':sha(out/'INFERENCE_SEALED.json'),
  'original_archive_sha256':sha('/mnt/data/CalligraGuard_new_Lao_event_20261023.zip'),'original_files_unchanged':len(lock['original_file_sha256']),
  'solver_sha256':sha(ROOT/'code/budgeted_solver.py'),'audit_sha256':sha(__file__),'new_neural_training':False,'live_IBM_state_checked':False}
 put(out/'VERIFIED.json',receipt);put(out/'COMPLETE.json',receipt);put(out/'STATUS.json',{'status':'complete_verified','outputs':48})
 print('VERIFIED',json.dumps(counts),flush=True);print('SUMMARY',json.dumps(summary),flush=True)
 print('KNOWN_FEASIBLE',json.dumps([{k:r[k] for k in ['master','method','strict_fit','approximate_fit','worst_fit_sse_ratio','check_worst_sse_ratio','render_calls']} for r in records if r['known_feasible_regression_case']]),flush=True)
if __name__=='__main__':main()
