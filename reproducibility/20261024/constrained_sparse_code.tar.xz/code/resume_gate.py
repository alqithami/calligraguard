"""Reporting-only recovery: normalize NumPy scalars, retain valid saved outputs.
Scientific solver and original runner files/settings remain unchanged.
Unsaved searches must be re-executed; this is not a claim of zero repeated computation.
"""
from pathlib import Path
import json,hashlib,datetime,time,concurrent.futures,fcntl,traceback
import numpy as np
import run_gate as r
ROOT=r.ROOT

def normalize(x):
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,dict):return {k:normalize(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [normalize(v) for v in x]
 return x

def put(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(p.suffix+'.tmp')
 temp.write_text(json.dumps(normalize(x),indent=2,allow_nan=False)+'\n');temp.replace(p)

def main():
 out=ROOT/'results';f=(out/'RUN.lock').open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB)
 lock=json.loads((out/'PROTOCOL_LOCK.json').read_text());sources=lock['source_sha256']
 assert all(r.sha(ROOT/p)==h for p,h in sources.items())
 manifest=json.loads((ROOT/'private_artifacts/INFERENCE_MANIFEST.json').read_text())
 saved={};todo=[]
 for item in manifest:
  for n in [1,4]:
   for method in r.s.CONFIG['methods']:
    name=f'm{item["master"]}_freeze{n}_{method}.json';path=out/'outputs'/name
    if path.exists():
     z=json.loads(path.read_text());assert z['master']==item['master'] and z['method']==method and z['frozen_count']==n
     assert z['input_image_hashes']==item['image_array_hashes'];assert z['render_calls']<=8000
     saved[name]=r.sha(path)
    else:todo.append((item,n,method))
 if (out/'INFERENCE_COMPLETE.json').exists():raise FileExistsError('Already complete')
 olderror=out/'FAILED.json';attempt=out/'attempts';attempt.mkdir(exist_ok=True)
 if olderror.exists():olderror.rename(attempt/'SERIALIZATION_FAILED.json')
 put(out/'RECOVERY_PROTOCOL.json',{'utc':r.utc(),'saved_outputs':len(saved),'unsaved_searches_to_repeat':len(todo),
   'saved_sha256':saved,'original_solver_unchanged':r.sha(ROOT/'code/budgeted_solver.py'),
   'change':'Normalize NumPy scalar values only during JSON serialization',
   'reporting_wrapper_sha256':r.sha(__file__),'original_numerical_settings':r.s.CONFIG,
   'timing_scope':'resumed phase is not total wall time; discarded first-attempt computation is not included in per-output successful-run timing'})
 r.put=put;start=time.perf_counter();finished=len(saved)
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  for future in concurrent.futures.as_completed([pool.submit(r.one,t) for t in todo]):
   future.result();finished+=1;put(out/'STATUS.json',{'status':'running_reporting_recovery','completed':finished,'expected':48,'utc':r.utc()})
 assert all(r.sha(out/'outputs'/p)==h for p,h in saved.items())
 assert all(r.sha(ROOT/p)==h for p,h in sources.items())
 sealed={p.name:r.sha(p) for p in (out/'outputs').glob('*.json')};assert len(sealed)==48
 put(out/'INFERENCE_SEALED.json',{'utc':r.utc(),'sha256':sealed})
 put(out/'INFERENCE_COMPLETE.json',{'status':'all_48_outputs_sealed_after_reporting_recovery','utc':r.utc(),'outputs':48,'seconds':time.perf_counter()-start,'seconds_scope':'recovery phase, not full attempted study','saved_outputs_reused':len(saved),'missing_outputs_reexecuted':len(todo),'no_neural_training':True})
 put(out/'STATUS.json',{'status':'inference_complete_evaluation_pending','completed':48,'expected':48,'utc':r.utc()})
 print('ALL_INFERENCE_COMPLETE',flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:put(ROOT/'results/FAILED.json',{'error':str(e),'traceback':traceback.format_exc(),'utc':r.utc()});raise
