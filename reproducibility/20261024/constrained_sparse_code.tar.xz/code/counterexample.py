"""Matched local inverse controls and source-counterexample searches.
Success is an explicitly replayed alternative, conditional on an error tolerance.
A failed local search NEVER certifies source necessity or a unique historical cause.
"""
from __future__ import annotations
import os
for key in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[key]='1'
import time, numpy as np
from scipy.ndimage import gaussian_filter
from forward_model import compile_master,render,ORIGIN

SETTINGS={'fit_ppem':[192,384],'check_ppem':[256,512], 'finite_difference_fu':1.,
          'max_iterations':18,'smoothing_schedule':[1.,.5,0.], 'ridge':1e-7,
          'max_step_fu':24.,'coordinate_bound_em':.2,'node_budgets':[4,8],
          'pattern_steps_fu':[2.,.5,.125],'pattern_trials_per_scale':120,
          'strict_pixel_epsilon_gray':1,'approximate_max_per_view_sse_ratio':.05,
          'methods':['nearest_node','node4','node8','dense','without_nearest_top1','without_nearest_top4'],
          'scope':'local numerical search, not a certified exhaustive explanation set'}

class Forward:
    def __init__(self,ref,observations):
        self.ref=ref;self.q=[np.asarray(q) for q in observations];self.n=len(ref['nodes']);self.calls=0;self.builds=0
        if len(self.q)!=2 or any(q.shape!=(768,768) or q.dtype!=np.uint8 for q in self.q):raise ValueError('Invalid observations')
        self.zero=np.zeros((self.n,2));self.base=self.images(self.zero);self.rois=[]
        for q,r in zip(self.q,self.base):
            y,x=np.where((q<255)|(r<255))
            if len(x)==0:raise ValueError('Empty glyph')
            self.rois.append((slice(max(0,y.min()-8),min(768,y.max()+9)),slice(max(0,x.min()-8),min(768,x.max()+9))))
    def images(self,delta):
        b=compile_master(self.ref,delta);self.builds+=1;out=[]
        for size in SETTINGS['fit_ppem']:out.append(render(b,size)[0]);self.calls+=1
        return out
    def vector(self,images,sigma=0.):
        return np.concatenate([gaussian_filter(im[roi].astype(float)/255.,sigma).ravel() for im,roi in zip(images,self.rois)])
    def jac(self,delta,support,sigma):
        cols=[];step=SETTINGS['finite_difference_fu']
        for j in support:
            for ax in [0,1]:
                plus=delta.copy();minus=delta.copy();plus[j,ax]+=step;minus[j,ax]-=step
                cols.append((self.vector(self.images(plus),sigma)-self.vector(self.images(minus),sigma))/(2*step))
        return np.stack(cols,1)

def nearest_ranking(ref,q,r):
    n=len(ref['nodes']);weights=np.zeros(n)
    for im,base,size in zip(q,r,SETTINGS['fit_ppem']):
        ys,xs=np.where(im!=base);xy=np.array([[x['x'],x['y']] for x in ref['nodes']])*size/ref['units_per_em']
        xy[:,0]+=ORIGIN[0];xy[:,1]=ORIGIN[1]-xy[:,1]
        for start in range(0,len(xs),2048):
            xx,yy=xs[start:start+2048],ys[start:start+2048];p=np.c_[xx+.5,yy+.5]
            ids=np.square(p[:,None]-xy[None]).sum(2).argmin(1)
            weights+=np.bincount(ids,weights=abs(im[yy,xx].astype(int)-base[yy,xx]),minlength=n)
    return np.argsort(-weights,kind='stable').tolist(),weights.tolist()

def refine(fw,support,initial):
    d=initial.copy();support=sorted(support);bound=fw.ref['units_per_em']*SETTINGS['coordinate_bound_em'];trace=[]
    if not support:return d,trace
    for step in range(SETTINGS['max_iterations']):
        sigma=SETTINGS['smoothing_schedule'][min(2,step//6)]
        y=fw.vector(fw.q,sigma);current=fw.vector(fw.images(d),sigma);res=y-current;J=fw.jac(d,support,sigma)
        x=d[support].ravel();H=J.T@J;ridge=SETTINGS['ridge'];damping=max(float(np.trace(H))/max(len(x),1)*.01,1e-8)
        update=np.linalg.solve(H+(ridge+damping)*np.eye(len(x)),J.T@res-ridge*x)
        update=np.clip(update,-SETTINGS['max_step_fu'],SETTINGS['max_step_fu']).reshape(-1,2)
        loss=float(res@res+ridge*(x@x));best=(loss,d)
        for eta in [1.,.5,.25]:
            trial=d.copy();trial[support]=np.clip(d[support]+eta*update,-bound,bound)
            e=y-fw.vector(fw.images(trial),sigma);z=trial[support].ravel();v=float(e@e+ridge*(z@z))
            if v<best[0]:best=(v,trial)
        trace.append({'iteration':step+1,'sigma':sigma,'before':loss,'after':best[0]});d=best[1]
    # Same quality-control budget for every fitted method. Original result and zero remain candidates.
    def raw(x):
        e=fw.vector(fw.q)-fw.vector(fw.images(x));return float(e@e+SETTINGS['ridge']*np.square(x).sum())
    zero=np.zeros_like(d);value=raw(d);z=raw(zero)
    if z<value:d=zero;value=z
    for size in SETTINGS['pattern_steps_fu']:
        used=0
        while used<SETTINGS['pattern_trials_per_scale']:
            best=(value,d);used_before=used
            for j in support:
                for ax in [0,1]:
                    for sign in [-1.,1.]:
                        if used>=SETTINGS['pattern_trials_per_scale']:break
                        t=d.copy();t[j,ax]=np.clip(t[j,ax]+sign*size,-bound,bound)
                        if np.array_equal(t,d):continue
                        v=raw(t);used+=1
                        if v<best[0]-1e-14:best=(v,t)
            trace.append({'phase':'coordinate_quality_control','step_fu':size,'trials':used,'before':value,'after':best[0]})
            if best[0]>=value-1e-14 or used==used_before:break
            value,d=best
    return d,trace

def infer(reference,observations,method):
    if method not in SETTINGS['methods']:raise ValueError('Unknown method')
    started=time.perf_counter();fw=Forward(reference,observations);d=fw.zero.copy()
    nearest,weights=nearest_ranking(reference,fw.q,fw.base)
    isnull=all(np.max(abs(a.astype(int)-b.astype(int)))<=1 for a,b in zip(fw.q,fw.base))
    frozen=[];support=[];trace=[]
    if not isnull and method!='nearest_node':
        if method.startswith('without_nearest_'):
            count=1 if method.endswith('top1') else 4;frozen=nearest[:count];support=[i for i in range(fw.n) if i not in frozen]
        elif method=='dense':support=list(range(fw.n))
        else:
            budget=4 if method=='node4' else 8;J=fw.jac(d,list(range(fw.n)),.5)
            y=fw.vector(fw.q,.5)-fw.vector(fw.base,.5);res=y.copy()
            for _ in range(budget):
                candidates=[]
                for j in range(fw.n):
                    if j in support:continue
                    A=J[:,2*j:2*j+2];coef=np.linalg.solve(A.T@A+SETTINGS['ridge']*np.eye(2),A.T@res)
                    err=res-A@coef;candidates.append((float(res@res-err@err),j))
                gain,j=max(candidates,key=lambda p:(p[0],-p[1]))
                if gain<=1e-12:break
                support.append(j);ix=[2*j+a for j in support for a in [0,1]];A=J[:,ix]
                coef=np.linalg.solve(A.T@A+SETTINGS['ridge']*np.eye(len(ix)),A.T@y)
                coef=np.clip(coef,-reference['units_per_em']*.2,reference['units_per_em']*.2)
                d[support]=coef.reshape(-1,2);res=y-A@coef
        d,trace=refine(fw,support,d)
    if frozen and np.any(d[frozen]!=0):raise AssertionError('Counterexample changed the excluded source')
    predicted=fw.images(d);fit=[]
    for ppem,q,b,p in zip(SETTINGS['fit_ppem'],fw.q,fw.base,predicted):
        e=q.astype(float)-p;null=q.astype(float)-b;sse=float(np.square(e).sum());den=float(np.square(null).sum())
        fit.append({'ppem':ppem,'squared_error':sse,'null_squared_error':den,'relative_sse':sse/den if den else None,'max_absolute_gray_error':float(abs(e).max())})
    strict=all(x['max_absolute_gray_error']<=1 for x in fit)
    approximate=all(x['relative_sse'] is not None and x['relative_sse']<=.05 for x in fit)
    if isnull:status='unchanged_source_compatible'
    elif method=='nearest_node':status='ranking_only_not_a_source_explanation'
    elif frozen:status='strict_counterexample_found' if strict else 'approximate_counterexample_only' if approximate else 'no_counterexample_found_necessity_unknown'
    else:status='strict_raster_match_not_unique_history' if strict else 'local_fit_not_unique_history'
    ranking=nearest if method=='nearest_node' else np.argsort(-np.linalg.norm(d,axis=1),kind='stable').tolist()
    return {'method':method,'status':status,'source_displacements':d.tolist(),'selected_nodes':support,'frozen_nodes':frozen,
            'node_ranking':ranking,'nearest_node_ranking':nearest,'nearest_positive_weights':weights,
            'fit_views':fit,'strict_fit_match':strict,'approximate_fit_match':approximate,'null_compatible':isnull,
            'iterations':trace,'font_compilations':fw.builds,'render_calls':fw.calls,'seconds':time.perf_counter()-started,
            'necessity_certified':False,'unique_history_certified':False,'test_images_or_patch_read':False}
