from __future__ import annotations
import os
for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import json,hashlib,datetime,concurrent.futures,time,traceback,fcntl
import numpy as np
import budgeted_solver as s
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(x,indent=2,allow_nan=False)+'\n');t.replace(p)
def one(task):
 item,freeze,method=task;private=ROOT/'private_artifacts/inference'
 assert sha(private/item['reference'])==item['reference_sha256'];assert sha(private/item['images'])==item['images_sha256']
 ref=json.loads((private/item['reference']).read_text())
 with np.load(private/item['images'],allow_pickle=False) as z:q=z['images'].copy()
 r=s.infer(ref,list(q),method,freeze,s.CONFIG['render_call_cap']);r.update(master=item['master'],input_image_hashes=item['image_array_hashes'])
 p=ROOT/'results/outputs'/f'm{item["master"]}_freeze{freeze}_{method}.json'
 if p.exists():raise FileExistsError('Refusing to overwrite inference')
 put(p,r)
 print('OUTPUT',item['master'],freeze,method,r['status'],r['render_calls'],round(r['seconds'],2),flush=True)
 return p.name

def main():
 out=ROOT/'results';lock=(out/'RUN.lock').open('a');fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
 if (out/'PROTOCOL_LOCK.json').exists():raise FileExistsError('Study exists; do not relaunch')
 tests=json.loads((out/'SOFTWARE_TESTS.json').read_text());assert tests['status']=='PASS' and tests['solver_sha256']==sha(ROOT/'code/budgeted_solver.py')
 sources={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'code').glob('*.py')}
 original={str(p.relative_to(ROOT/'upstream_original')):sha(p) for p in (ROOT/'upstream_original').rglob('*') if p.is_file() and '__pycache__' not in p.parts}
 manifest=json.loads((ROOT/'private_artifacts/INFERENCE_MANIFEST.json').read_text())
 put(out/'PROTOCOL_LOCK.json',{'declared_utc':utc(),'settings':s.CONFIG,'solver_comparison':'same 8000-render-call ceiling, shared numerical refinement and acquisition; actual cost reported',
  'master_count':6,'target_freezes':[1,4],'planned_outputs':48,'prior_counterexample_outputs':'retained as historical controls; not claimed matched current timing',
  'source_sha256':sources,'upstream_archive_sha256':sha('/mnt/data/CalligraGuard_new_Lao_event_20261023.zip'),'original_file_sha256':original,
  'input_manifest_sha256':sha(ROOT/'private_artifacts/INFERENCE_MANIFEST.json'),
  'the_two_prior_known_feasible_cases':'regression tests, not independent confirmation',
  'development_caveat':'all Lao masters previously evaluated; no novelty or production guarantee',
  'strict_endpoint_unchanged':True,'approximate_5pct_endpoint_unchanged':True,'selection':'all six masters, both freezing rules, every arm',
  'no_history_input':'workers only open reference/fit arrays; historical coordinates excluded from API',
  'source_access_contract':'controlled rendering with logged origin and trusted repaired reference; candidate original outline withheld from solver',
  'multi_start_compute':'all shared initialization and each start charged to same total call ceiling; no archived free warm starts'})
 tasks=[(e,n,m) for e in manifest for n in [1,4] for m in s.CONFIG['methods']]
 start=time.perf_counter();done=[]
 with concurrent.futures.ProcessPoolExecutor(max_workers=4) as pool:
  futures=[pool.submit(one,t) for t in tasks]
  for future in concurrent.futures.as_completed(futures):
   done.append(future.result());put(out/'STATUS.json',{'status':'running','completed':len(done),'expected':48,'updated_utc':utc()})
 assert sources=={n:sha(ROOT/n) for n in sources}
 assert original=={n:sha(ROOT/'upstream_original'/n) for n in original}
 sealed={p.name:sha(p) for p in (out/'outputs').glob('*.json')};assert len(sealed)==48
 put(out/'INFERENCE_SEALED.json',{'utc':utc(),'sha256':sealed})
 put(out/'INFERENCE_COMPLETE.json',{'status':'all_48_outputs_sealed','utc':utc(),'outputs':48,'seconds':time.perf_counter()-start,'no_neural_training':True})
 put(out/'STATUS.json',{'status':'inference_complete_evaluation_pending','completed':48,'expected':48,'updated_utc':utc()})
 print('ALL_INFERENCE_COMPLETE',time.perf_counter()-start,flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:put(ROOT/'results/FAILED.json',{'utc':utc(),'error':str(e),'traceback':traceback.format_exc()});raise
