"""Download two pinned full files privately and verify original bytes and canonical geometry.
This narrow extractor is only for the exact pinned six-layer oO-lao event.
Do not use it as a general Glyphs parser or redistribute downloaded font sources.
"""
from pathlib import Path
from urllib.request import urlopen,Request
import argparse,re,json,hashlib
PINS={
'before':('9850ada7ac6358471ac5d5608f62fa35bf1a1921','d75b5c60ec64528aedd0a406384fd48cd28eb041','fb7834b0fb0ef84c6dcd46cee37eefad9afe438929b9cce372f0e3c2f2258354'),
'after':('6587aedd3e0511c1546a3c1855502b7f5aa54d1b','cd06925eb26d8941098032dea59498f0c3c658b1','635b4c5a500074bf8bb0ae6eb1e2f245aef37d0d84173e82ca1c1694121c1efb')}
def extract(text):
 assert re.search(r'\bunitsPerEm = 1000;',text)
 block=text.split('glyphname = "oO-lao";',1)[1].split('note = uni0EAD;',1)[0];layers=[]
 for lid,body,width in re.findall(r'layerId = "([^"]+)";\s*paths = \((.*?)\nwidth = (\d+);',block,re.S):
  nodes=[];contours=[]
  for ci,part in enumerate(re.findall(r'closed = 1;\s*nodes = \((.*?)\n\);',body,re.S)):
   ix=[]
   for ni,(x,y,typ,smooth) in enumerate(re.findall(r'"(-?\d+(?:\.\d+)?) (-?\d+(?:\.\d+)?) (OFFCURVE|CURVE|LINE)( SMOOTH)?"',part)):
    ix.append(len(nodes));nodes.append({'contour':ci,'node':ni,'x':float(x),'y':float(y),'type':{'OFFCURVE':'o','CURVE':'c','LINE':'l'}[typ]+('s' if smooth else '')})
   contours.append(ix)
  assert len(nodes)==44
  layers.append({'schema':'cg.historical.reference.v2','glyph_name':'oO-lao','master_id':lid,'units_per_em':1000,'width':float(width),'nodes':nodes,'contours':contours})
 assert len(layers)==6;return layers

def acquire(out):
 out=Path(out);out.mkdir(parents=True,exist_ok=True,mode=0o700);receipt={}
 for label,(revision,blob,expected) in PINS.items():
  url=f'https://raw.githubusercontent.com/notofonts/Noto-Lao/{revision}/src/NotoSansLao-MM.glyphs'
  with urlopen(Request(url,headers={'User-Agent':'CalligraGuard-reproduction'}),timeout=60) as r:raw=r.read()
  actual=hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
  if actual!=blob:raise ValueError('Pinned Git blob mismatch')
  geometry=extract(raw.decode());b=json.dumps(geometry,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()
  if hashlib.sha256(b).hexdigest()!=expected:raise ValueError('Canonical geometry mismatch')
  for name,data in [(label+'.glyphs',raw),(label+'.json',b)]:
   p=out/name
   if p.exists() and p.read_bytes()!=data:raise FileExistsError('Different existing source '+str(p))
   p.write_bytes(data);p.chmod(0o600)
  receipt[label]={'url':url,'git_blob':actual,'source_sha256':hashlib.sha256(raw).hexdigest(),'geometry_sha256':expected,'bytes':len(raw)}
 (out/'SOURCE_BYTES_VERIFIED.json').write_text(json.dumps(receipt,indent=2)+'\n');return receipt
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();print(json.dumps(acquire(a.out),indent=2))
