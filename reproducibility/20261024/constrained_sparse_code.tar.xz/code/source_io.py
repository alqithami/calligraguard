"""Strict OpenStep subset reader and foreground-only glyph extraction.
No source-file text or font binaries are bundled with the deliverable.
"""
from __future__ import annotations
import re, json, hashlib
from typing import Any

TOKEN = re.compile(r'\s+|/\*.*?\*/|//[^\n]*|"(?:\\.|[^"\\])*"|[{}()=;,]|[^\s{}()=;,"/]+', re.S)

def parse_openstep(text: str) -> dict:
    tokens=[]; position=0
    for m in TOKEN.finditer(text):
        if text[position:m.start()].strip():raise ValueError('Unsupported token at '+str(position))
        t=m.group();position=m.end()
        if t.isspace() or t.startswith('/*') or t.startswith('//'):continue
        tokens.append(t)
    if text[position:].strip():raise ValueError('Unparsed trailing input')
    i=0
    def val():
        nonlocal i
        if i>=len(tokens):raise ValueError('Truncated source')
        t=tokens[i];i+=1
        if t=='{':
            out={}
            while i<len(tokens) and tokens[i]!='}':
                key=val()
                if not isinstance(key,str) or key in out:raise ValueError('Invalid or duplicate dictionary key')
                if i>=len(tokens) or tokens[i]!='=':raise ValueError('Missing =')
                i+=1;out[key]=val()
                if i>=len(tokens) or tokens[i]!=';':raise ValueError('Missing ;')
                i+=1
            if i>=len(tokens):raise ValueError('Unclosed dictionary')
            i+=1;return out
        if t=='(':
            out=[]
            while i<len(tokens) and tokens[i]!=')':
                out.append(val())
                if i<len(tokens) and tokens[i]==',':i+=1
                elif i<len(tokens) and tokens[i]!=')':raise ValueError('Missing list comma')
            if i>=len(tokens):raise ValueError('Unclosed list')
            i+=1;return out
        if t in ['}',')','=',';',',']:raise ValueError('Unexpected delimiter')
        if t.startswith('"'):
            # OpenStep supports quoted strings with backslash/octal escapes.
            body=t[1:-1]
            return re.sub(r'\\([0-7]{3}|.)',lambda m:chr(int(m[1],8)) if re.fullmatch('[0-7]{3}',m[1]) else {'n':'\n','t':'\t','r':'\r'}.get(m[1],m[1]),body)
        return t
    out=val()
    if i!=len(tokens) or not isinstance(out,dict):raise ValueError('Not one complete dictionary')
    return out

def extract_glyph(document: dict, glyph: str) -> list[dict]:
    upm=int(document['unitsPerEm'])
    if not 16<=upm<=16384:raise ValueError('Invalid unitsPerEm')
    matches=[g for g in document['glyphs'] if g.get('glyphname')==glyph]
    if len(matches)!=1:raise ValueError('Glyph missing or duplicated')
    layers=[];seen=set()
    for layer in matches[0]['layers']:
        lid=layer['layerId']
        if lid in seen:raise ValueError('Duplicated layer ID')
        seen.add(lid)
        # Only top-level active foreground paths; never traverse background dictionaries.
        shapes=layer.get('paths',layer.get('shapes'))
        if shapes is None:raise ValueError('Missing foreground geometry')
        nodes=[];contours=[]
        for ci,path in enumerate(shapes):
            if set(path)-{'closed','nodes'}:raise ValueError('Components/transforms or unsupported path fields')
            if int(path['closed'])!=1:raise ValueError('Open contour unsupported')
            ids=[]
            for ni,node in enumerate(path['nodes']):
                if isinstance(node,str):
                    m=re.fullmatch(r'(-?\d+(?:\.\d+)?)\s+(-?\d+(?:\.\d+)?)\s+(OFFCURVE|CURVE|LINE)(?: (SMOOTH))?',node)
                    if not m:raise ValueError('Unknown legacy node syntax')
                    x,y,kind,smooth=m.groups();kind={'OFFCURVE':'o','CURVE':'c','LINE':'l'}[kind]+('s' if smooth else '')
                elif isinstance(node,list) and len(node)==3:x,y,kind=node
                else:raise ValueError('Unknown foreground node representation')
                if kind not in ['o','c','cs','l','ls']:raise ValueError('Unsupported curve type')
                ids.append(len(nodes));nodes.append({'contour':ci,'node':ni,'x':float(x),'y':float(y),'type':kind})
            if len(ids)<3:raise ValueError('Degenerate path')
            contours.append(ids)
        layers.append({'schema':'cg.historical.reference.v2','glyph_name':glyph,'master_id':lid,'units_per_em':upm,
                       'width':float(layer['width']),'nodes':nodes,'contours':contours})
    return layers

def canonical(data: Any) -> bytes:
    return json.dumps(data,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False).encode()

def digest(data: Any) -> str:return hashlib.sha256(canonical(data)).hexdigest()

def source_difference(before,after):
    if before['master_id']!=after['master_id'] or before['contours']!=after['contours'] or before['width']!=after['width']:raise ValueError('Incomparable topology/width')
    if [(n['contour'],n['node'],n['type']) for n in before['nodes']]!=[(n['contour'],n['node'],n['type']) for n in after['nodes']]:raise ValueError('No exact node correspondence')
    return [i for i,(a,b) in enumerate(zip(before['nodes'],after['nodes'])) if a['x']!=b['x'] or a['y']!=b['y']]
