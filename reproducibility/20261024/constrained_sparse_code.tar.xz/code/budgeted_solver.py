"""Constrained sparse regression gate. Standard local numerical controls, not novel theory.
Inference consumes reference geometry, candidate fit images and a frozen-node count.
No historical edits, candidate source geometry or check-size images are accepted.
"""
from __future__ import annotations
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:
    os.environ[k]='1'
import time, math
import numpy as np
from scipy.ndimage import gaussian_filter
from forward_model import compile_master, render
from counterexample import nearest_ranking

CONFIG = {
    'methods':['dense_zero','constrained_sparse4','constrained_sparse8','constrained_multistart'],
    'fit_ppem':[192,384], 'check_ppem':[256,512],
    'render_call_cap':8000, 'coordinate_bound_em':.2,
    'node_budgets':[4,8], 'gauss_newton_iterations':18,
    'smoothing_schedule':[1.,.5,0.], 'finite_difference_fu':1.,
    'step_cap_fu':24., 'ridge':1e-7,
    'line_search':[1.,.5,.25,.125],
    'poll_steps_fu':[2.,.5,.125], 'poll_sweeps_per_scale':3,
    'multistarts':['sparse4_linear','sparse8_linear','sparse8_zero'],
    'strict_pixel_epsilon':1, 'approximate_max_per_view_sse_ratio':.05,
    'decision':'failed local search never certifies necessity',
    'objective':'minimize worst per-view raw SSE ratio; lexicographic mean ratio tie-break; strict witnesses retained',
    'scope':'known-event engineering regression, not independent novelty evidence'
}

class BudgetExceeded(RuntimeError): pass


def score_images(observations, predictions, denominators):
    out=[]
    for q,p,den,size in zip(observations,predictions,denominators,CONFIG['fit_ppem']):
        e=q.astype(np.float64)-p
        sse=float(np.square(e).sum())
        out.append({'ppem':size,'sse':sse,'null_sse':float(den),
                    'ratio':sse/den if den else None,
                    'max_gray_error':int(np.abs(e).max())})
    return out


def score_key(views):
    strict=all(v['max_gray_error']<=CONFIG['strict_pixel_epsilon'] for v in views)
    r=[v['ratio'] for v in views]
    if any(x is None for x in r):
        return (0 if strict else 1,0. if strict else math.inf,0.)
    return (0 if strict else 1,max(r),math.fsum(r)/len(r))


def complete_poll_directions(support, sweep=0):
    # Rotate starting coordinates. Every scheduled sweep is complete, or not started.
    coordinates=[(j,a) for j in sorted(support) for a in [0,1]]
    if coordinates:
        k=sweep % len(coordinates); coordinates=coordinates[k:]+coordinates[:k]
    return [(j,a,s) for j,a in coordinates for s in [-1.,1.]]


class Engine:
    def __init__(self, reference, observations, cap):
        self.ref=reference; self.q=[np.asarray(q) for q in observations]
        self.n=len(reference['nodes']); self.cap=int(cap); self.calls=0;self.builds=0
        if len(self.q)!=2 or any(q.dtype!=np.uint8 or q.shape!=(768,768) for q in self.q):
            raise ValueError('Two full uint8 fitting images required')
        self.zero=np.zeros((self.n,2));self.frozen=[];self.trace=[]
        self.base=self.raw_images(self.zero)
        self.den=np.array([np.square(q.astype(float)-r).sum() for q,r in zip(self.q,self.base)])
        self.rois=[]
        for q,r in zip(self.q,self.base):
            yy,xx=np.where((q<255)|(r<255))
            if len(xx)==0:raise ValueError('Empty foreground')
            self.rois.append((slice(max(0,int(yy.min())-8),min(768,int(yy.max())+9)),
                              slice(max(0,int(xx.min())-8),min(768,int(xx.max())+9))))
        self.best_delta=self.zero.copy();self.best_views=score_images(self.q,self.base,self.den)
        self.best_key=score_key(self.best_views)
        self.best_support=[];self.best_origin='unchanged_reference'
        self.den_vector=np.maximum(self.den/255.**2,1e-16)
    def raw_images(self,d):
        if self.calls+2>self.cap:raise BudgetExceeded('Rendering ceiling reached')
        font=compile_master(self.ref,d);self.builds+=1
        self.calls+=2
        return [render(font,s)[0] for s in CONFIG['fit_ppem']]
    def candidate(self,d,support,origin):
        d=np.asarray(d,float)
        if d.shape!=(self.n,2) or not np.isfinite(d).all():raise ValueError('Bad source coordinates')
        if np.max(abs(d))>self.ref['units_per_em']*.2+1e-10:raise ValueError('Displacement bound')
        if self.frozen and np.any(d[self.frozen]!=0):raise ValueError('Frozen coordinate altered')
        images=self.raw_images(d);views=score_images(self.q,images,self.den);key=score_key(views)
        if key<self.best_key:
            self.best_key=key;self.best_delta=d.copy();self.best_views=views
            self.best_support=list(support);self.best_origin=origin
        return images,views
    def vectors(self,images,sigma):
        return [gaussian_filter(im[roi].astype(float)/255.,sigma).ravel()/math.sqrt(den)
                for im,roi,den in zip(images,self.rois,self.den_vector)]
    def jacobian(self,d,support,sigma):
        columns=[]
        for j in support:
            for a in [0,1]:
                p=d.copy();n=d.copy();p[j,a]+=1.;n[j,a]-=1.
                # Derivative queries can touch one unit outside the permitted fit box.
                # They are never accepted as source explanations.
                vp=self.vectors(self.raw_images(p),sigma);vn=self.vectors(self.raw_images(n),sigma)
                columns.append(np.concatenate([(x-y)/2 for x,y in zip(vp,vn)]))
        return np.stack(columns,1)


def sparse_initialize(engine,allowed,budget,J,y):
    support=[];res=y.copy();delta=engine.zero.copy();index={j:i for i,j in enumerate(allowed)}
    ridge=CONFIG['ridge']
    for _ in range(min(budget,len(allowed))):
        choices=[]
        for j in allowed:
            if j in support:continue
            ix=2*index[j];A=J[:,ix:ix+2]
            c=np.linalg.solve(A.T@A+ridge*np.eye(2),A.T@res)
            rem=res-A@c;choices.append((float(res@res-rem@rem),j))
        if not choices:break
        gain,j=max(choices,key=lambda x:(x[0],-x[1]))
        if gain<=1e-12:break
        support.append(j);ix=[2*index[k]+a for k in support for a in [0,1]];A=J[:,ix]
        c=np.linalg.solve(A.T@A+ridge*np.eye(len(ix)),A.T@y)
        c=c.clip(-engine.ref['units_per_em']*.2,engine.ref['units_per_em']*.2)
        delta[support]=c.reshape(-1,2);res=y-A@c
    return sorted(support),delta


def refine(engine,support,initial,end_calls,label):
    d=initial.copy();support=sorted(support);limit=min(engine.cap,end_calls)
    bound=engine.ref['units_per_em']*.2;trace=[]
    if not support:return trace
    if engine.calls+2>limit:return trace
    current_images,current_views=engine.candidate(d,support,label+':initial')
    if score_key(engine.best_views)[0]==0:return trace
    # Reserve at least one complete coordinate sweep per scale when possible.
    reserve=2*4*len(support)*len(CONFIG['poll_steps_fu'])
    for iteration in range(CONFIG['gauss_newton_iterations']):
        needed=8*len(support)+2*len(CONFIG['line_search'])
        if engine.calls+needed>limit-reserve:break
        sigma=CONFIG['smoothing_schedule'][min(2,iteration//6)]
        target=engine.vectors(engine.q,sigma);pred=engine.vectors(current_images,sigma)
        residual=np.concatenate([q-p for q,p in zip(target,pred)])
        J=engine.jacobian(d,support,sigma);x=d[support].ravel()
        # Same normalized proposal model for every arm. Accept by full-image worst-view loss.
        H=J.T@J;damping=max(float(np.trace(H))/len(x)*.01,1e-8)
        step=np.linalg.solve(H+(CONFIG['ridge']+damping)*np.eye(len(x)),J.T@residual-CONFIG['ridge']*x)
        step=step.clip(-CONFIG['step_cap_fu'],CONFIG['step_cap_fu']).reshape(-1,2)
        key=score_key(current_views);best=(key,d,current_images,current_views)
        for eta in CONFIG['line_search']:
            trial=d.copy();trial[support]=np.clip(d[support]+eta*step,-bound,bound)
            images,views=engine.candidate(trial,support,label+':gn')
            if score_key(views)<best[0]:best=(score_key(views),trial,images,views)
        trace.append({'phase':'normalized_gn','iteration':iteration+1,'sigma':sigma,
                      'accepted':best[0]<key,'worst_ratio':best[0][1],'render_calls':engine.calls})
        _,d,current_images,current_views=best
        if engine.best_key[0]==0:return trace
    sweep_id=0
    for step in CONFIG['poll_steps_fu']:
        for _ in range(CONFIG['poll_sweeps_per_scale']):
            directions=complete_poll_directions(support,sweep_id);sweep_id+=1
            if engine.calls+2*len(directions)>limit:
                trace.append({'phase':'full_sweep_not_started_budget','step':step,'required_calls':2*len(directions),'remaining_calls':limit-engine.calls})
                break
            key=score_key(current_views);best=(key,d,current_images,current_views)
            for j,a,sign in directions:
                trial=d.copy();trial[j,a]=np.clip(trial[j,a]+sign*step,-bound,bound)
                images,views=engine.candidate(trial,support,label+':poll')
                if score_key(views)<best[0]:best=(score_key(views),trial,images,views)
            trace.append({'phase':'complete_coordinate_sweep','step':step,'coordinates_tested':2*len(support),
                          'directional_trials':len(directions),'accepted':best[0]<key,'render_calls':engine.calls})
            _,d,current_images,current_views=best
            if engine.best_key[0]==0:return trace
            if best[0]>=key:break
    return trace


def infer(reference,observations,method,frozen_count,render_cap=8000):
    if method not in CONFIG['methods'] or frozen_count not in [1,4]:raise ValueError('Invalid configuration')
    started=time.perf_counter();e=Engine(reference,observations,render_cap)
    nearest,weights=nearest_ranking(reference,e.q,e.base);e.frozen=nearest[:frozen_count]
    null=all(v['max_gray_error']<=1 for v in e.best_views)
    trace=[];starts=[];allowed=[j for j in range(e.n) if j not in e.frozen]
    if not null:
        if method=='dense_zero':starts=[('dense_zero',allowed,e.zero.copy())]
        else:
            J=e.jacobian(e.zero,allowed,.5)
            y=np.concatenate([q-r for q,r in zip(e.vectors(e.q,.5),e.vectors(e.base,.5))])
            if method=='constrained_sparse4':
                s,d=sparse_initialize(e,allowed,4,J,y);starts=[('sparse4_linear',s,d)]
            elif method=='constrained_sparse8':
                s,d=sparse_initialize(e,allowed,8,J,y);starts=[('sparse8_linear',s,d)]
            else:
                s4,d4=sparse_initialize(e,allowed,4,J,y);s8,d8=sparse_initialize(e,allowed,8,J,y)
                starts=[('sparse4_linear',s4,d4),('sparse8_linear',s8,d8),('sparse8_zero',s8,e.zero.copy())]
        for index,(label,support,d) in enumerate(starts):
            remaining_starts=len(starts)-index;allocation=(e.cap-e.calls)//remaining_starts
            end=e.calls+allocation
            trace.extend([{'start':label,**r} for r in refine(e,support,d,end,label)])
            if e.best_key[0]==0:break
    if e.calls>render_cap or np.any(e.best_delta[e.frozen]!=0):raise AssertionError('Budget or freeze violated')
    strict=all(v['max_gray_error']<=1 for v in e.best_views)
    approximate=all(v['ratio'] is not None and v['ratio']<=.05 for v in e.best_views)
    status='unchanged_source_compatible' if null else 'strict_counterexample_found' if strict else 'approximate_counterexample_only' if approximate else 'no_counterexample_found_necessity_unknown'
    return {'method':method,'frozen_count':frozen_count,'frozen_nodes':e.frozen,'nearest_ranking':nearest,
            'status':status,'strict_fit':strict,'approximate_fit':approximate,'null_compatible':null,
            'source_displacements':e.best_delta.tolist(),'selected_nodes':e.best_support,
            'best_origin':e.best_origin,'fit_views':e.best_views,'render_calls':e.calls,'font_builds':e.builds,
            'render_cap':render_cap,'unused_render_budget':render_cap-e.calls,'seconds':time.perf_counter()-started,
            'starts_scheduled':[{'name':n,'support':s} for n,s,d in starts],'trace':trace,
            'necessity_certified':False,'history_or_check_size_read':False}
