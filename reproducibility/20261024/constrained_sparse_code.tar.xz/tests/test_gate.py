import sys,unittest,inspect,json
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'code'))
import budgeted_solver as b
from forward_model import compile_master,render
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  cls.ref={'nodes':[{'x':80.,'y':0.,'type':'l'},{'x':240.,'y':0.,'type':'l'},{'x':240.,'y':240.,'type':'l'},{'x':80.,'y':240.,'type':'l'}], 'contours':[[0,1,2,3]],'units_per_em':1000,'width':400.}
  cls.images=[render(compile_master(cls.ref),p)[0] for p in [192,384]]
 def test_sweep_all_coordinates(self):
  d=b.complete_poll_directions(list(range(43)))
  self.assertEqual(len(d),172);self.assertEqual(len(set(d)),172)
 def test_rotated_sweep_same_set(self):
  a=b.complete_poll_directions([3,7,13],0);c=b.complete_poll_directions([3,7,13],2)
  self.assertEqual(set(a),set(c));self.assertNotEqual(a[0],c[0])
 def test_strict_precedence(self):
  self.assertLess(b.score_key([{'max_gray_error':1,'ratio':.4}]*2),b.score_key([{'max_gray_error':2,'ratio':.0001}]*2))
 def test_worst_view_not_pooled(self):
  k=b.score_key([{'max_gray_error':4,'ratio':.01},{'max_gray_error':5,'ratio':.2}]);self.assertEqual(k[1],.2)
 def test_inference_api_no_truth(self):
  self.assertEqual(list(inspect.signature(b.infer).parameters),['reference','observations','method','frozen_count','render_cap'])
 def test_bad_method(self):
  with self.assertRaises(ValueError):b.infer(self.ref,self.images,'oracle',1)
 def test_bad_freeze(self):
  with self.assertRaises(ValueError):b.infer(self.ref,self.images,'dense_zero',2)
 def test_null_uses_only_baseline(self):
  r=b.infer(self.ref,self.images,'constrained_sparse4',1,2)
  self.assertEqual(r['render_calls'],2);self.assertTrue(r['null_compatible']);self.assertFalse(np.array(r['source_displacements']).any())
 def test_budget_hard_limit(self):
  e=b.Engine(self.ref,self.images,2)
  with self.assertRaises(b.BudgetExceeded):e.raw_images(e.zero)
  self.assertEqual(e.calls,2)
 def test_frozen_coordinates_rejected(self):
  e=b.Engine(self.ref,self.images,4);e.frozen=[1];d=e.zero.copy();d[1,0]=1
  with self.assertRaises(ValueError):e.candidate(d,[1],'bad')
 def test_input_shape_rejected(self):
  with self.assertRaises(ValueError):b.Engine(self.ref,[np.zeros((10,10),np.uint8)]*2,4)
 def test_sparse_support_excludes_frozen(self):
  class E:
   n=4;ref={'units_per_em':1000};zero=np.zeros((4,2))
  J=np.eye(6);y=np.array([0,0,1,2,0,0.]);s,d=b.sparse_initialize(E(),[0,2,3],1,J,y)
  self.assertEqual(s,[2]);self.assertFalse(d[1].any())
 def test_finite_coefficients(self):
  class E:
   n=4;ref={'units_per_em':1000};zero=np.zeros((4,2))
  s,d=b.sparse_initialize(E(),[0,2,3],2,np.zeros((10,6)),np.ones(10))
  self.assertEqual(s,[]);self.assertTrue(np.isfinite(d).all())
 def test_final_source_not_modified(self):
  before=json.dumps(self.ref,sort_keys=True);b.infer(self.ref,self.images,'constrained_multistart',4,2)
  self.assertEqual(before,json.dumps(self.ref,sort_keys=True))
if __name__=='__main__':
 suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests);r=unittest.TextTestRunner(verbosity=2).run(suite)
 p=Path(__file__).resolve().parents[1]/'results/SOFTWARE_TESTS.json'
 import hashlib
 p.write_text(json.dumps({'status':'PASS' if r.wasSuccessful() else 'FAIL','tests':r.testsRun,'failures':len(r.failures),'errors':len(r.errors),'solver_sha256':hashlib.sha256(Path(b.__file__).read_bytes()).hexdigest()},indent=2))
 raise SystemExit(0 if r.wasSuccessful() else 1)
