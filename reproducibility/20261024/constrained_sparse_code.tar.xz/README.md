# Constrained-sparse baseline: executed code and verification summary

This is the 48-output corrected baseline on the previously assessed Lao event, not a novel algorithm. Sparse-four/eight/multistart passed the approximate fitting criterion in 3/6 altered searches; dense zero-start passed none. No strict all-pixel success. All four methods had an 8,000 fitting-render-call ceiling.

This public code bundle contains numerical and portable reproduction code, unit tests, requirements, the executed audit summary, and pinned prior capture receipts required by the wrapper. The full 48 optimizer traces, evaluated outputs and recovery logs remain in the privately preserved original CalligraGuard_constrained_sparse_gate_20261024.zip. No inference was repeated for packaging.

Create an isolated environment; pip install -r requirements.txt; python -m unittest discover -s tests -p test_gate.py; python code/portable_reproduce.py --output ./new_run --workers 4. Network access is required to acquire pinned sources privately. Capture hashes must match. Never include the acquired font sources or binaries in distributed results. Absolute-path archived run/evaluation files describe the executed environment; use portable_reproduce.py rather than overwriting earlier results. A failed search does not establish necessity or infeasibility.
