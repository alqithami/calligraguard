"""Source-available font QA primitives. Fonts stay in memory or private input paths.
No learned defect classifier, inverse optimizer or causal-identifiability claim.
"""
from __future__ import annotations
import copy, datetime, hashlib, io, json, math
from pathlib import Path
import numpy as np
import freetype
import uharfbuzz as hb
from fontTools.ttLib import TTFont
from fontTools.fontBuilder import FontBuilder
from fontTools.pens.t2CharStringPen import T2CharStringPen
from fontTools.pens.pointPen import PointToSegmentPen

ROOT=Path(__file__).resolve().parent.parent
PRIVATE=ROOT.parent/'solver_gate_20261024'/'private_artifacts'
SIZES=[16,32,64,128,256,512]
EXPECTED={
 'malayalam_before.glyphs':'ce87b9a9a1e690b817fa76c1bf5099d322f88e482a9e38557bac39365f8bc2a4',
 'malayalam_after.glyphs':'926a493c932923e6b51ed1cf7be710ed5cb77f20751175d9c02acc3f206268d0',
 'urdu_before.ttf':'b6707c30b7d58a6bd68830244a01721bd92b3c235c0109b0a865646a02730e23',
 'urdu_after.ttf':'25a3cc523ad6e0039b5324ebdb63b013e72ce228c3b80a97d3078c5e0e829582'}

def normalize(x):
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,dict):return {str(k):normalize(v) for k,v in x.items()}
 if isinstance(x,(tuple,list)):return [normalize(v) for v in x]
 return x

def put(path,value):
 p=Path(path);p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(p.suffix+'.tmp')
 tmp.write_text(json.dumps(normalize(value),indent=2,allow_nan=False)+'\n');tmp.replace(p)
def sha(b):return hashlib.sha256(b).hexdigest()
def file_sha(p):return sha(Path(p).read_bytes())
def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def verify_inputs():
 for name,digest in EXPECTED.items():
  if file_sha(PRIVATE/name)!=digest:raise ValueError('Private artifact hash mismatch: '+name)
 return dict(EXPECTED)

def face(data):return freetype.Face(io.BytesIO(data))
def render_gid(ft,gid,ppem,hinted=False,origin=(0.,0.)):
 ft.set_pixel_sizes(0,int(ppem));xy=np.rint(np.array(origin)*64).astype(int)
 xi=math.floor(xy[0]/64);yi=math.floor(xy[1]/64)
 ft.set_transform(freetype.Matrix(65536,0,0,65536),freetype.Vector(int(xy[0]-64*xi),int(64*yi-xy[1])))
 flags=freetype.FT_LOAD_RENDER|freetype.FT_LOAD_NO_BITMAP
 if not hinted:flags|=freetype.FT_LOAD_NO_HINTING|freetype.FT_LOAD_NO_AUTOHINT
 ft.load_glyph(int(gid),flags);bm=ft.glyph.bitmap
 if bm.rows and bm.width:
  if bm.pixel_mode!=freetype.FT_PIXEL_MODE_GRAY:raise ValueError('Expected grayscale bitmap')
  im=np.array(bm.buffer,dtype=np.uint8).reshape(bm.rows,abs(bm.pitch))[:,:bm.width].copy()
  if bm.pitch<0:im=im[::-1].copy()
 else:im=np.zeros((0,0),np.uint8)
 x=xi+int(ft.glyph.bitmap_left);y=yi-int(ft.glyph.bitmap_top)
 return {'image':im,'x':x,'y':y,'advance_26_6':[int(ft.glyph.advance.x),int(ft.glyph.advance.y)],'flags':int(flags),'origin_26_6':xy.tolist()}

def raster_hash(r):
 m={k:r[k] for k in ['x','y','advance_26_6']};m['shape']=list(r['image'].shape)
 return sha(json.dumps(m,sort_keys=True).encode()+r['image'].tobytes())
def place_on_union(a,b):
 nonempty=[r for r in [a,b] if r['image'].size]
 if not nonempty:return np.zeros((1,1),np.uint8),np.zeros((1,1),np.uint8)
 x0=min(r['x'] for r in nonempty);y0=min(r['y'] for r in nonempty)
 x1=max(r['x']+r['image'].shape[1] for r in nonempty);y1=max(r['y']+r['image'].shape[0] for r in nonempty)
 if (x1-x0)*(y1-y0)>40_000_000:raise ValueError('Unexpectedly large raster union')
 out=[]
 for r in [a,b]:
  c=np.zeros((y1-y0,x1-x0),np.uint8)
  if r['image'].size:
   h,w=r['image'].shape;c[r['y']-y0:r['y']-y0+h,r['x']-x0:r['x']-x0+w]=r['image']
  out.append(c)
 return out

def metrics(a,b):
 x,y=place_on_union(a,b);d=x.astype(np.int32)-y.astype(np.int32);mag=abs(d)
 return {'changed_pixels_gt1':int(np.count_nonzero(mag>1)),'max_gray_error':int(mag.max(initial=0)),
  'squared_error':int(np.square(d,dtype=np.int64).sum()),'absolute_error':int(mag.sum()),
  'bitwise_image_equal':bool(np.array_equal(x,y)),'binary_foreground_disagreement':int(np.count_nonzero((x>=128)!=(y>=128))),
  'advance_equal':a['advance_26_6']==b['advance_26_6'],'before_hash':raster_hash(a),'after_hash':raster_hash(b)}

def shape(data,text):
 font=hb.Font(hb.Face(data));hb.ot_font_set_funcs(font);upm=font.face.upem;font.scale=(upm,upm)
 buf=hb.Buffer();buf.add_str(text);buf.direction='rtl';buf.script='arab';buf.language='ur';hb.shape(font,buf)
 return [{'gid':int(i.codepoint),'cluster':int(i.cluster),'x_advance':int(p.x_advance),'y_advance':int(p.y_advance),'x_offset':int(p.x_offset),'y_offset':int(p.y_offset)} for i,p in zip(buf.glyph_infos,buf.glyph_positions)],upm

def render_text(data,text,ppem,hinted=False):
 seq,upm=shape(data,text);ft=face(data);x=y=0.;pieces=[]
 for s in seq:
  p=render_gid(ft,s['gid'],ppem,hinted,((x+s['x_offset'])*ppem/upm,-(y+s['y_offset'])*ppem/upm));pieces.append(p)
  x+=s['x_advance'];y+=s['y_advance']
 nonempty=[p for p in pieces if p['image'].size]
 if not nonempty:return {'image':np.zeros((0,0),np.uint8),'x':0,'y':0,'advance_26_6':[round(x*ppem/upm*64),round(y*ppem/upm*64)]},seq
 x0=min(p['x'] for p in nonempty);y0=min(p['y'] for p in nonempty);x1=max(p['x']+p['image'].shape[1] for p in nonempty);y1=max(p['y']+p['image'].shape[0] for p in nonempty)
 # Reproducible black-on-white alpha-over composition, integer arithmetic.
 im=np.zeros((y1-y0,x1-x0),np.uint8)
 for p in nonempty:
  h,w=p['image'].shape;view=im[p['y']-y0:p['y']-y0+h,p['x']-x0:p['x']-x0+w];a=p['image'].astype(np.uint32);b=view.astype(np.uint32)
  view[:]=(255-((255-a)*(255-b)+127)//255).astype(np.uint8)
 return {'image':im,'x':x0,'y':y0,'advance_26_6':[round(x*ppem/upm*64),round(y*ppem/upm*64)]},seq

def tt(data):return TTFont(io.BytesIO(data),recalcTimestamp=False)
def save_tt(font):
 font.recalcTimestamp=False;buf=io.BytesIO();font.save(buf,reorderTables=False);return buf.getvalue()
def swap_glyphs(base_data,donor_data,gids):
 base=tt(base_data);donor=tt(donor_data)
 if base.getGlyphOrder()!=donor.getGlyphOrder():raise ValueError('Glyph order differs')
 for gid in gids:
  name=base.getGlyphName(int(gid));base['glyf'][name]=copy.deepcopy(donor['glyf'][name])
 return save_tt(base)

def layer_record(layer):
 if layer.components:raise ValueError('Standalone reconstruction does not silently decompose components')
 contours=[]
 for path in layer.paths:
  if not path.closed:raise ValueError('Open contour unsupported')
  contours.append([{'x':float(n.position.x),'y':float(n.position.y),'type':n.type,'smooth':bool(n.smooth)} for n in path.nodes])
 return {'layer_id':layer.layerId,'width':float(layer.width),'contours':contours}

def compile_layer(record,upm=1000):
 pen=T2CharStringPen(record['width'],None,roundTolerance=0);point=PointToSegmentPen(pen)
 for contour in record['contours']:
  point.beginPath()
  for n in contour:
   typ=None if n['type']=='offcurve' else n['type']
   if typ not in [None,'line','curve','qcurve']:raise ValueError('Unknown source node type')
   point.addPoint((n['x'],n['y']),segmentType=typ,smooth=n['smooth'])
  point.endPath()
 fb=FontBuilder(int(upm),isTTF=False);fb.setupGlyphOrder(['.notdef','observed']);fb.setupCharacterMap({65:'observed'})
 fb.setupHorizontalMetrics({'.notdef':(500,0),'observed':(round(record['width']),0)});fb.setupHorizontalHeader(ascent=1200,descent=-400)
 fb.setupNameTable({'familyName':'Private QA reconstruction','styleName':'Regular','uniqueFontIdentifier':'CG-QA','fullName':'Private QA reconstruction','psName':'CGQA'})
 fb.setupOS2(sTypoAscender=1200,sTypoDescender=-400,usWinAscent=1200,usWinDescent=400);fb.setupPost()
 fb.setupCFF('CGQA',{'FullName':'Private QA reconstruction','FamilyName':'Private QA reconstruction','Weight':'Regular'},
  {'.notdef':T2CharStringPen(500,None).getCharString(),'observed':pen.getCharString()}, {})
 fb.font.recalcTimestamp=False;fb.font['head'].created=2082844800;fb.font['head'].modified=2082844800;buf=io.BytesIO();fb.save(buf);return buf.getvalue()

def screenshot_pair(a,b,path):
 from PIL import Image,ImageDraw
 x,y=place_on_union(a,b);pad=8;w=x.shape[1];h=x.shape[0]
 if w<24 or h<24:
  factor=max(1,min(8,math.ceil(32/max(w,h,1))));x=np.repeat(np.repeat(x,factor,0),factor,1);y=np.repeat(np.repeat(y,factor,0),factor,1);w=x.shape[1];h=x.shape[0]
 out=Image.new('L',(3*w+4*pad,h+32+2*pad),255);draw=ImageDraw.Draw(out)
 for i,(label,im) in enumerate([('before',255-x),('after',255-y),('absolute difference',255-abs(x.astype(int)-y.astype(int)).astype(np.uint8))]):
  out.paste(Image.fromarray(im),(pad+i*(w+pad),32+pad));draw.text((pad+i*(w+pad),8),label,fill=0)
 out.save(path)
