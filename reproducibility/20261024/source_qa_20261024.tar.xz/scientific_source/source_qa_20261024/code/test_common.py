#!/usr/bin/env python3
"""Numerical/API fixtures; not natural-defect evidence."""
import copy,inspect,json,tempfile,unittest
from pathlib import Path
import numpy as np
from common import *
from run_study import canon,minimal_sets
FIXTURE={'layer_id':'toy','width':600.,'contours':[[
 {'x':50.,'y':0.,'type':'line','smooth':False},{'x':450.,'y':0.,'type':'line','smooth':False},
 {'x':450.,'y':500.,'type':'line','smooth':False},{'x':50.,'y':500.,'type':'line','smooth':False}]]}
class Tests(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.data=compile_layer(FIXTURE)
 def test_compile_deterministic(self):self.assertEqual(self.data,compile_layer(FIXTURE))
 def test_compile_preserves_input(self):
  old=copy.deepcopy(FIXTURE);compile_layer(FIXTURE);self.assertEqual(old,FIXTURE)
 def test_nonempty(self):self.assertGreater(render_gid(face(self.data),1,64)['image'].sum(),0)
 def test_exact_null(self):
  r=render_gid(face(self.data),1,64);self.assertTrue(metrics(r,r)['bitwise_image_equal'])
 def test_displacement_visible(self):
  r=copy.deepcopy(FIXTURE);r['contours'][0][1]['x']+=40
  self.assertGreater(metrics(render_gid(face(self.data),1,64),render_gid(face(compile_layer(r)),1,64))['changed_pixels_gt1'],0)
 def test_cyclic_start(self):
  r=copy.deepcopy(FIXTURE);r['contours'][0]=r['contours'][0][1:]+r['contours'][0][:1]
  self.assertTrue(metrics(render_gid(face(self.data),1,64),render_gid(face(compile_layer(r)),1,64))['bitwise_image_equal'])
 def test_smooth_flag(self):
  r=copy.deepcopy(FIXTURE)
  for n in r['contours'][0]:n['smooth']=True
  self.assertTrue(metrics(render_gid(face(self.data),1,64),render_gid(face(compile_layer(r)),1,64))['bitwise_image_equal'])
 def test_unknown_type(self):
  r=copy.deepcopy(FIXTURE);r['contours'][0][0]['type']='unknown'
  with self.assertRaises(ValueError):compile_layer(r)
 def test_offset_not_normalized_away(self):
  a=render_gid(face(self.data),1,64);b=render_gid(face(self.data),1,64,origin=(2,0))
  self.assertGreater(metrics(a,b)['changed_pixels_gt1'],0)
 def test_padding_not_difference(self):
  a={'image':np.array([[50,100]],np.uint8),'x':0,'y':0,'advance_26_6':[0,0]}
  b={'image':np.array([[0,0,0,0],[0,50,100,0],[0,0,0,0]],np.uint8),'x':-1,'y':-1,'advance_26_6':[0,0]}
  self.assertTrue(metrics(a,b)['bitwise_image_equal'])
 def test_int64_sse(self):
  a={'image':np.full((512,512),255,np.uint8),'x':0,'y':0,'advance_26_6':[0,0]};b={**a,'image':np.zeros((512,512),np.uint8)}
  self.assertEqual(metrics(a,b)['squared_error'],512*512*255*255)
 def test_empty(self):
  a={'image':np.zeros((0,0),np.uint8),'x':0,'y':0,'advance_26_6':[0,0]};self.assertTrue(metrics(a,a)['bitwise_image_equal'])
 def test_canonical_preserves_orientation(self):
  a=[(0,0,1),(1,0,1),(1,1,1)];self.assertNotEqual(canon(a),canon(a[::-1]))
 def test_undirected_blindness(self):
  a=[(0,0,1),(1,0,1),(1,1,1)];self.assertEqual(canon(a,True),canon(a[::-1],True))
 def test_minimal_subsets(self):self.assertEqual(minimal_sets([[1],[1,2],[2],[1,2,3]]),[[1],[2]])
 def test_empty_swap_is_minimal(self):self.assertEqual(minimal_sets([[],[1],[1,2]]),[[]])
 def test_numpy_serialization(self):
  s=json.dumps(normalize({'a':np.int64(3),'b':np.bool_(True),'c':np.array([1.,2.])}),allow_nan=False);self.assertEqual(json.loads(s)['a'],3)
 def test_nan_refused(self):
  with tempfile.TemporaryDirectory() as d:
   with self.assertRaises(ValueError):put(Path(d)/'nan.json',{'x':float('nan')})
 def test_actual_origin_record(self):
  r=render_gid(face(self.data),1,64,origin=(.125,.375));self.assertEqual(r['origin_26_6'],[8,24])
 def test_nonhint_flags(self):
  r=render_gid(face(self.data),1,64);self.assertTrue(r['flags']&freetype.FT_LOAD_NO_HINTING)

if __name__=='__main__':
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Tests))
 report={'status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),
         'common_sha256':file_sha(Path(__file__).parent/'common.py'),'test_sha256':file_sha(__file__),'scope':'toy API and pixel arithmetic tests, not historical performance'}
 put(ROOT/'results/SOFTWARE_TESTS.json',report);print(json.dumps(report));raise SystemExit(0 if result.wasSuccessful() else 1)
