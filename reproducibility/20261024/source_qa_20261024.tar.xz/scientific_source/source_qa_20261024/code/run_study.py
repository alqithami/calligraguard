#!/usr/bin/env python3
"""Two-event source-available QA audit: direct differences, visibility, exact swap replay.
All eligible masters/glyphs included. No model training and no automatic intent labels.
"""
from __future__ import annotations
import copy,gzip,hashlib,itertools,json,time,traceback
from pathlib import Path
import numpy as np
from glyphsLib import GSFont
from fontTools.ttLib.tables._g_l_y_f import GlyphCoordinates
from common import *
TEXTS=['ت','پ','ث','ي','بت','بيت','پت','ثب','يي','ﺕ ﭖ ﺙ ﻱ']
HINTS=[False,True]
REPLAY_SIZES=[64,128,256]
CONTROL_KINDS=['metadata_only','cyclic_point_start','all_contours_reversed','declared_intentional_translation']

def contours(glyph):
 result=[];start=0
 for end in glyph.endPtsOfContours:
  result.append([(int(glyph.coordinates[j][0]),int(glyph.coordinates[j][1]),int(glyph.flags[j])&1) for j in range(start,end+1)]);start=end+1
 return result

def canon(points,reverse=False):
 if not points:return ()
 x=[tuple(q) for q in points];options=[tuple(x[i:]+x[:i]) for i in range(len(x))]
 if reverse:
  y=list(reversed(x));options += [tuple(y[i:]+y[:i]) for i in range(len(y))]
 return min(options)

def dependencies(font):
 names=font.getGlyphOrder();cache={};visiting=set()
 def walk(name):
  if name in cache:return cache[name]
  if name in visiting:raise ValueError('Composite cycle')
  visiting.add(name);ans={font.getGlyphID(name)};g=font['glyf'][name]
  if g.isComposite():
   for component in g.components:ans|=walk(component.glyphName)
  visiting.remove(name);cache[name]=ans;return ans
 return {gid:walk(name) for gid,name in enumerate(names)}

def raw_glyphs(font):
 data=font.getTableData('glyf');loc=font['loca'].locations
 return [data[loc[i]:loc[i+1]] for i in range(len(loc)-1)]

def minimal_sets(matches):
 return sorted([x for x in matches if not any(set(y)<set(x) for y in matches)],key=lambda x:(len(x),x))

def control_font(data,gid,kind):
 f=tt(data);name=f.getGlyphName(gid);g=f['glyf'][name]
 if kind=='metadata_only':
  for item in f['name'].names:
   if item.nameID==1:
    try:item.string=(item.toUnicode()+' QA metadata control').encode(item.getEncoding())
    except UnicodeError:continue
 else:
  if g.isComposite():raise ValueError('Control expects simple glyph')
  coords=list(g.coordinates);flags=list(g.flags);start=0
  for end in g.endPtsOfContours:
   ix=list(range(start,end+1));start=end+1
   if kind=='cyclic_point_start' and len(ix)>1:ix=ix[1:]+ix[:1]
   elif kind=='all_contours_reversed':ix=list(reversed(ix))
   elif kind!='declared_intentional_translation' and kind!='cyclic_point_start':raise ValueError(kind)
   a=end-len(ix)+1
   coords[a:end+1]=[tuple(g.coordinates[j]) for j in ix];flags[a:end+1]=[g.flags[j] for j in ix]
  if kind=='declared_intentional_translation':coords=[(x+8,y) for x,y in coords]
  g.coordinates=GlyphCoordinates(coords);g.flags=bytearray(flags)
 return save_tt(f)

def urdu():
 started=time.perf_counter();before=(PRIVATE/'urdu_before.ttf').read_bytes();after=(PRIVATE/'urdu_after.ttf').read_bytes();f0=tt(before);f1=tt(after)
 assert f0.getGlyphOrder()==f1.getGlyphOrder();n=len(f1.getGlyphOrder());b0=raw_glyphs(f0);b1=raw_glyphs(f1)
 changed=[i for i,(a,b) in enumerate(zip(b0,b1)) if a!=b]
 if not changed or len(changed)>8:raise ValueError('Expected bounded changed-glyph subset')
 graph=dependencies(f1);affected=[gid for gid,s in graph.items() if set(changed)&s]
 structure=[]
 for gid in changed:
  a=contours(f0['glyf'][f0.getGlyphName(gid)]);b=contours(f1['glyf'][f1.getGlyphName(gid)])
  oriented=sorted(canon(c) for c in a)==sorted(canon(c) for c in b)
  undirected=sorted(canon(c,True) for c in a)==sorted(canon(c,True) for c in b)
  structure.append({'gid':gid,'contours_before':len(a),'contours_after':len(b),'oriented_geometry_equal':oriented,'unoriented_geometry_equal':undirected})
 put(ROOT/'results/urdu_structure.json',{'glyph_count':n,'changed_glyph_ids':changed,'dependency_affected_glyph_ids':affected,'records':structure})
 ft0=face(before);ft1=face(after);visual=[];failed=[];rowcount=0;digest=hashlib.sha256()
 stream=gzip.open(ROOT/'results/urdu_all_glyphs.jsonl.gz','wt')
 for ppem in SIZES:
  for hinted in HINTS:
   significant=[];nonbitwise=[]
   for gid in range(n):
    try:
     a=render_gid(ft0,gid,ppem,hinted);b=render_gid(ft1,gid,ppem,hinted);m=metrics(a,b)
     row={'gid':gid,'ppem':ppem,'hinted':hinted,**m};rowcount+=1
     encoded=json.dumps(row,sort_keys=True)+'\n';digest.update(encoded.encode());stream.write(encoded)
     if m['changed_pixels_gt1']:significant.append(gid)
     if not m['bitwise_image_equal']:nonbitwise.append(gid)
     if ppem==128 and not hinted and gid in changed:screenshot_pair(a,b,ROOT/f'figures/urdu_gid{gid}_128.png')
    except Exception as e:failed.append({'gid':gid,'ppem':ppem,'hinted':hinted,'error':type(e).__name__+': '+str(e)})
   visual.append({'ppem':ppem,'hinted':hinted,'visible_changed_gids_gt1':significant,'any_pixel_changed_gids':nonbitwise,
                  'unexplained_outside_source_dependency':sorted(set(significant)-set(affected))})
   print('URDU_GLYPH_SCAN',ppem,hinted,len(significant),'visible',flush=True)
 stream.close()
 # Texts are fixed before rendering; no selection based on visible differences.
 textrows=[];textbases={}
 for text in TEXTS:
  seq0,u=shape(before,text);seq1,_=shape(after,text)
  if seq0!=seq1:raise ValueError('Layout changed; glyph-only replay contract insufficient')
  affected_in_text=sorted(set().union(*(graph[r['gid']] for r in seq1))&set(changed))
  for ppem in SIZES:
   for hinted in HINTS:
    a,_=render_text(before,text,ppem,hinted);b,_=render_text(after,text,ppem,hinted)
    m=metrics(a,b);textrows.append({'text':text,'ppem':ppem,'hinted':hinted,'shaped_gids':[r['gid'] for r in seq1],'dependency_source_gids':affected_in_text,**m})
    if ppem in REPLAY_SIZES and not hinted:textbases[(text,ppem)]=(a,b)
  a,b=textbases[(text,128)];screenshot_pair(a,b,ROOT/('figures/urdu_text_'+sha(text.encode())[:8]+'.png'))
 put(ROOT/'results/urdu_texts.json',textrows)
 variants={mask:swap_glyphs(before,after,[gid for i,gid in enumerate(changed) if (mask>>i)&1]) for mask in range(1<<len(changed))}
 replay=[];replay_calls=0
 for text in TEXTS:
  for ppem in REPLAY_SIZES:
   a,target=textbases[(text,ppem)];matches=[];traces=[]
   for mask,data in variants.items():
    predicted,seq=render_text(data,text,ppem,False);m=metrics(predicted,target);replay_calls+=1
    ids=[gid for i,gid in enumerate(changed) if (mask>>i)&1]
    if m['bitwise_image_equal'] and m['advance_equal']:matches.append(ids)
    traces.append({'replacement_gids':ids,'hash':raster_hash(predicted),'pixel_error':m['max_gray_error'],'sse':m['squared_error'],'matches_after':m['bitwise_image_equal'] and m['advance_equal']})
   assert changed in matches
   replay.append({'text':text,'ppem':ppem,'before_after_changed_gt1':metrics(a,target)['changed_pixels_gt1']>0,
                  'matching_subsets':matches,'inclusion_minimal_subsets':minimal_sets(matches),'traces':traces,
                  'interpretation':'exact within enumerated original-to-repaired glyph-record swaps and measured acquisition; not unique real-world cause'})
 put(ROOT/'results/urdu_swap_replay.json',replay)
 controls=[];gid=changed[0]
 for kind in CONTROL_KINDS:
  data=control_font(after,gid,kind);cf=face(data);native=tt(data)
  raw_changed=raw_glyphs(native)[gid]!=raw_glyphs(f1)[gid]
  before_contours=contours(f1['glyf'][f1.getGlyphName(gid)]);new_contours=contours(native['glyf'][native.getGlyphName(gid)])
  sem=sorted(canon(c) for c in before_contours)!=sorted(canon(c) for c in new_contours)
  for ppem in SIZES:
   a=render_gid(ft1,gid,ppem,False);b=render_gid(cf,gid,ppem,False)
   controls.append({'kind':kind,'gid':gid,'ppem':ppem,'font_bytes_different':data!=after,'raw_glyph_changed':raw_changed,'oriented_cyclic_source_changed':sem,**metrics(a,b),
      'label':'controlled_declared_intent_not_a_defect_judgment' if kind=='declared_intentional_translation' else 'controlled_representation_or_metadata_change'})
 put(ROOT/'results/urdu_controls.json',controls)
 result={'status':'urdu_source_available_comparison_complete','event_count':1,'original_full_font_binaries_used':True,'glyph_count':n,'direct_glyph_changes':changed,'dependency_affected_glyphs':affected,
  'oriented_changes':[r['gid'] for r in structure if not r['oriented_geometry_equal']],'unoriented_changes':[r['gid'] for r in structure if not r['unoriented_geometry_equal']],
  'glyph_render_comparisons':rowcount,'glyph_render_failures':failed,'all_glyph_stream_sha256':file_sha(ROOT/'results/urdu_all_glyphs.jsonl.gz'),'all_glyph_uncompressed_digest':digest.hexdigest(),
  'glyph_scan':visual,'text_comparisons':len(textrows),'text_changed_gt1':sum(r['changed_pixels_gt1']>0 for r in textrows),
  'font_variants_built_in_memory':len(variants),'replay_text_configurations':len(replay),'replay_text_renderings':replay_calls,'controlled_change_comparisons':len(controls),
  'control_summary':{kind:{'cases':len([r for r in controls if r['kind']==kind]),'visibly_different_gt1':sum(r['changed_pixels_gt1']>0 for r in controls if r['kind']==kind),'bitwise_equal':sum(r['bitwise_image_equal'] for r in controls if r['kind']==kind)} for kind in CONTROL_KINDS},
  'seconds':time.perf_counter()-started,'no_automatic_intent_classification':True}
 put(ROOT/'results/URDU_COMPLETE.json',result);return result

def foreground_sig(layer,smooth=False):
 paths=[{'closed':p.closed,'nodes':[(float(n.position.x),float(n.position.y),n.type,bool(n.smooth) if smooth else None) for n in p.nodes]} for p in layer.paths]
 comp=[(c.componentName,list(c.transform)) for c in layer.components]
 return {'width':float(layer.width),'paths':paths,'components':comp}

def malayalam():
 started=time.perf_counter();f0=GSFont(str(PRIVATE/'malayalam_before.glyphs'));f1=GSFont(str(PRIVATE/'malayalam_after.glyphs'))
 assert f0.upm==f1.upm==1000;masterids=[m.id for m in f1.masters];changed=[];compared=0;names0={g.name for g in f0.glyphs};names1={g.name for g in f1.glyphs}
 if names0!=names1:raise ValueError('Glyph population changed; not a paired-source contract')
 for name in sorted(names1):
  for mid in masterids:
   a=f0.glyphs[name].layers[mid];b=f1.glyphs[name].layers[mid];compared+=1
   if foreground_sig(a)!=foreground_sig(b):changed.append((name,mid))
 # Render every foreground layer of the source-changed glyph(s), including unchanged masters.
 changed_names=sorted({n for n,mid in changed});records=[];rows=[];replays=[];controls=[];compile_count=0
 for name in changed_names:
  for master in f1.masters:
   a=layer_record(f0.glyphs[name].layers[master.id]);b=layer_record(f1.glyphs[name].layers[master.id])
   aa=[v for c in a['contours'] for v in c];bb=[v for c in b['contours'] for v in c]
   structural=[len(c) for c in a['contours']]==[len(c) for c in b['contours']] and [n['type'] for n in aa]==[n['type'] for n in bb]
   if not structural:raise ValueError('Foreground coordinate mapping is ambiguous: '+master.id)
   edits=[i for i,(u,v) in enumerate(zip(aa,bb)) if (u['x'],u['y'])!=(v['x'],v['y'])]
   smooth=[i for i,(u,v) in enumerate(zip(aa,bb)) if u['smooth']!=v['smooth']]
   records.append({'glyph':name,'master_id':master.id,'master_name':master.name,'foreground_nodes':len(aa),'types_correspond':True,
     'coordinate_changed_nodes':edits,'smooth_flag_changed_nodes':smooth,'source_backgrounds_used':False})
   d0=compile_layer(a);d1=compile_layer(b);compile_count+=2;ft0=face(d0);ft1=face(d1);bases={}
   for ppem in SIZES:
    r0=render_gid(ft0,1,ppem,False,(.125,.375));r1=render_gid(ft1,1,ppem,False,(.125,.375));m=metrics(r0,r1);bases[ppem]=(r0,r1)
    rows.append({'glyph':name,'master_id':master.id,'ppem':ppem,**m})
    if ppem==128:screenshot_pair(r0,r1,ROOT/('figures/malayalam_'+master.id[:8]+'_128.png'))
   # All finite subsets of actual source-coordinate differences, not inferred history.
   if len(edits)>8:raise ValueError('Too many changes for fixed exact replay bound')
   alternatives={}
   for mask in range(1<<len(edits)):
    r=copy.deepcopy(a);nodes=[v for c in r['contours'] for v in c]
    for j,index in enumerate(edits):
     if (mask>>j)&1:nodes[index]['x']=bb[index]['x'];nodes[index]['y']=bb[index]['y']
    alternatives[mask]=compile_layer(r);compile_count+=1
   for ppem in REPLAY_SIZES:
    matches=[];traces=[];target=bases[ppem][1]
    for mask,data in alternatives.items():
     p=render_gid(face(data),1,ppem,False,(.125,.375));m=metrics(p,target);selected=[j for k,j in enumerate(edits) if (mask>>k)&1]
     if m['bitwise_image_equal'] and m['advance_equal']:matches.append(selected)
     traces.append({'replaced_node_indices':selected,'predicted_hash':raster_hash(p),'sse':m['squared_error'],'max_gray_error':m['max_gray_error']})
    assert edits in matches
    replays.append({'glyph':name,'master_id':master.id,'ppem':ppem,'actual_coordinate_changes':len(edits),'matching_subsets':matches,'inclusion_minimal_subsets':minimal_sets(matches),'traces':traces})
   # Metadata, smooth-handle flags and starting-index changes are NOT real labeled clean cases.
   variants={}
   r=copy.deepcopy(b)
   for c in r['contours']:
    for v in c:v['smooth']=not v['smooth']
   variants['smooth_flags_only']=r
   r=copy.deepcopy(b);r['contours']=[c[1:]+c[:1] for c in r['contours']];variants['cyclic_start']=r
   r=copy.deepcopy(b)
   for c in r['contours']:
    for v in c:v['x']+=8
   variants['declared_intentional_translation']=r
   for kind,r in variants.items():
    data=compile_layer(r);compile_count+=1
    for ppem in SIZES:
     p=render_gid(face(data),1,ppem,False,(.125,.375));q=bases[ppem][1]
     controls.append({'master_id':master.id,'kind':kind,'ppem':ppem,'compiled_bytes_changed':data!=d1,**metrics(q,p),'label':'controlled_intent_or_representation_change_not_expert_adjudication'})
   print('MALAYALAM_MASTER_COMPLETE',master.name,'changed_nodes',len(edits),flush=True)
 put(ROOT/'results/malayalam_sources.json',records);put(ROOT/'results/malayalam_visual.json',rows);put(ROOT/'results/malayalam_swap_replay.json',replays);put(ROOT/'results/malayalam_controls.json',controls)
 summary={'status':'malayalam_source_available_comparison_complete','event_count':1,'foreground_layers_compared':compared,'changed_foreground_layers':len(changed),'changed_glyphs':changed_names,
  'master_reconstructions':len(records),'original_node_type_correspondence_verified':len(records),'smooth_metadata_change_masters':sum(bool(r['smooth_flag_changed_nodes']) for r in records),
  'render_comparisons':len(rows),'visible_comparisons_gt1':sum(r['changed_pixels_gt1']>0 for r in rows),'bitwise_unchanged_comparisons':sum(r['bitwise_image_equal'] for r in rows),
  'visibility_by_ppem':{str(p):{'masters':sum(r['ppem']==p for r in rows),'changed_gt1':sum(r['ppem']==p and r['changed_pixels_gt1']>0 for r in rows)} for p in SIZES},
  'finite_swap_configurations':len(replays),'finite_swap_renderings':sum(len(r['traces']) for r in replays),'compiled_fonts_in_memory':compile_count,
  'control_comparisons':len(controls),'control_summary':{kind:{'cases':sum(r['kind']==kind for r in controls),'changed_gt1':sum(r['kind']==kind and r['changed_pixels_gt1']>0 for r in controls),'bitwise_equal':sum(r['kind']==kind and r['bitwise_image_equal'] for r in controls)} for kind in variants},
  'full_release_build':False,'production_shaping_tested':False,'known_acquisition_only':True,'no_automatic_intent_classification':True,'seconds':time.perf_counter()-started}
 put(ROOT/'results/MALAYALAM_COMPLETE.json',summary);return summary

def main():
 if (ROOT/'results/COMPLETE.json').exists():raise SystemExit('Already complete; do not rerun')
 if (ROOT/'results/PROTOCOL_LOCK.json').exists():raise SystemExit('Protocol exists; verify/resume explicitly rather than overwrite')
 inputs=verify_inputs();scripts={p.name:file_sha(p) for p in Path(__file__).parent.glob('*.py')}
 tests=json.loads((ROOT/'results/SOFTWARE_TESTS.json').read_text());assert tests['status']=='PASS' and tests['common_sha256']==scripts['common.py']
 put(ROOT/'results/PROTOCOL_LOCK.json',{'created_utc':utc(),'scope':'two maintainer-described repair events; source-available diagnostic development, not independent blinded validation',
  'source_sha256':scripts,'input_sha256':inputs,'sizes_ppem':SIZES,'urdu_hint_modes':HINTS,'urdu_texts':TEXTS,'replay_sizes':REPLAY_SIZES,
  'exhaustive_scope':'all 1141 original Urdu glyphs; all foreground masters of Malayalam source-changed glyphs; all original-to-repaired source-record subsets within <=8 changes',
  'visible_difference_rule':'absolute gray difference >1; also report any-bit differences, raw squared error and binary mask disagreement',
  'source_aware_baselines':['raw source/binary differences','oriented cyclic source signature','unoriented geometry signature','matched rendering differences','dependency trace','exhaustive actual-change replay'],
  'purpose':'link known source revisions to visible impact without misrepresenting ordinary diffing as novel source inference',
  'control_types':CONTROL_KINDS+['Malayalam smooth-only flag change'],'controlled_legitimacy':'intent controlled by construction, not human evidence of acceptable typography',
  'fonts_never_exported':True,'no_v3_retraining':True,'no_renderer_or_solver_parameter_selection_on_scores':True,'versions':{'freetype':freetype.version(),'harfbuzz':hb.version_string()}})
 start=time.perf_counter();u=urdu();put(ROOT/'results/STATUS.json',{'status':'running','urdu':'complete','malayalam':'pending','utc':utc()});m=malayalam()
 assert inputs==verify_inputs();assert scripts=={p.name:file_sha(p) for p in Path(__file__).parent.glob('*.py')}
 files={str(p.relative_to(ROOT)):file_sha(p) for p in (ROOT/'results').glob('*') if p.is_file() and p.name!='STATUS.json'}
 receipt={'status':'two_event_source_available_QA_complete','completed_utc':utc(),'seconds':time.perf_counter()-start,'source_hashes':scripts,'input_artifacts_unchanged':True,'results_sha256':files,
  'urdu':u,'malayalam':m,'no_learned_model_evaluation':True,'no_novelty_claim':True,'no_expert_defect_classification':True,'no_IBM_or_v3_access':True}
 put(ROOT/'results/COMPLETE.json',receipt);put(ROOT/'results/STATUS.json',{'status':'complete','completed_utc':receipt['completed_utc']});print('SOURCE_AVAILABLE_QA_COMPLETE',json.dumps(normalize(receipt),allow_nan=False),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:
  put(ROOT/'results/FAILED.json',{'error':repr(e),'traceback':traceback.format_exc(),'utc':utc()});raise
