from pathlib import Path
import sys
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'code'))
import common,run_study
common.ROOT=root/'recovery_1'
run_study.ROOT=common.ROOT
run_study.main()
