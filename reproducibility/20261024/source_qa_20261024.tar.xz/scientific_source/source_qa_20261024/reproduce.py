#!/usr/bin/env python3
"""Portable, fail-closed repetition of the completed source-available QA study.
No network, font redistribution, prior-result overwrite, or neural training.
"""
from __future__ import annotations
import argparse,runpy,sys,traceback
from pathlib import Path

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--private',type=Path,required=True,help='Directory containing the four pinned historical artifacts');ap.add_argument('--out',type=Path,required=True,help='A NEW output directory');args=ap.parse_args()
 root=Path(__file__).resolve().parent;out=args.out.resolve();private=args.private.resolve()
 if out.exists():raise FileExistsError('Refusing to overwrite '+str(out))
 if not private.is_dir():raise FileNotFoundError(private)
 sys.path.insert(0,str(root/'code'));import common
 common.PRIVATE=private;common.ROOT=out;common.verify_inputs();out.mkdir(parents=True)
 for name in ['results','figures','reports','provenance']:(out/name).mkdir()
 try:
  try:runpy.run_path(str(root/'code/test_common.py'),run_name='__main__')
  except SystemExit as e:
   if e.code not in [None,0]:raise RuntimeError('Numerical/API tests failed') from e
  import run_study
  run_study.ROOT=out;run_study.PRIVATE=private;run_study.main()
  import verify_study
  verify_study.OUT=out;verify_study.c.PRIVATE=private;verify_study.main()
 except Exception:
  common.put(out/'results/FAILED_PORTABLE.json',{'traceback':traceback.format_exc(),'utc':common.utc()});raise
 print('PORTABLE_SOURCE_QA_COMPLETE',out)
if __name__=='__main__':main()
