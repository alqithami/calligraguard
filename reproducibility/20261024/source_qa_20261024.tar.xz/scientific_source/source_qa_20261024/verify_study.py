#!/usr/bin/env python3
"""Saved-output audit, using independent bitmap-buffer extraction and pixel sums.
Shares FreeType/HarfBuzz and the source reconstruction/compiler; not a second renderer.
Does not select parameters, perform learning or inspect previous v3 runs.
"""
from pathlib import Path
import ctypes,gzip,hashlib,io,json,math,sys,time
import numpy as np
ROOT=Path(__file__).resolve().parent;OUT=ROOT/'recovery_1';sys.path.insert(0,str(ROOT/'code'))
import common as c
import run_study as study
import freetype
from glyphsLib import GSFont

def read(p):return json.loads(Path(p).read_text())
def independent_raster(ft,gid,ppem,hinted=False,origin=(0.,0.)):
 ft.set_pixel_sizes(0,ppem);xx,yy=[round(z*64) for z in origin];ix=xx//64;iy=yy//64
 ft.set_transform(freetype.Matrix(65536,0,0,65536),freetype.Vector(xx-ix*64,iy*64-yy))
 flags=freetype.FT_LOAD_RENDER|freetype.FT_LOAD_NO_BITMAP
 if not hinted:flags|=freetype.FT_LOAD_NO_HINTING|freetype.FT_LOAD_NO_AUTOHINT
 ft.load_glyph(gid,flags);bm=ft.glyph.bitmap
 if bm.rows and bm.width:
  data=ctypes.string_at(bm._FT_Bitmap.buffer,bm.rows*abs(bm.pitch))
  a=np.frombuffer(data,np.uint8).reshape(bm.rows,abs(bm.pitch))[:,:bm.width].copy()
  if bm.pitch<0:a=a[::-1].copy()
 else:a=np.zeros((0,0),np.uint8)
 return {'image':a,'x':ix+ft.glyph.bitmap_left,'y':iy-ft.glyph.bitmap_top,'advance_26_6':[int(ft.glyph.advance.x),int(ft.glyph.advance.y)]}

def independent_metrics(a,b):
 rr=[r for r in [a,b] if r['image'].size]
 if not rr:diff=np.zeros((1,1),np.int64)
 else:
  x0=min(r['x'] for r in rr);y0=min(r['y'] for r in rr);x1=max(r['x']+r['image'].shape[1] for r in rr);y1=max(r['y']+r['image'].shape[0] for r in rr)
  diff=np.zeros((y1-y0,x1-x0),np.int64)
  for sign,r in zip([1,-1],[a,b]):
   if r['image'].size:
    h,w=r['image'].shape;diff[r['y']-y0:r['y']-y0+h,r['x']-x0:r['x']-x0+w]+=sign*r['image'].astype(np.int64)
 return {'changed_pixels_gt1':int((abs(diff)>1).sum()),'max_gray_error':int(abs(diff).max(initial=0)),
         'squared_error':int((diff*diff).sum()),'absolute_error':int(abs(diff).sum()),'bitwise_image_equal':not np.any(diff)}

def checked(a,b,row,keys=None):
 m=independent_metrics(a,b)
 for key in (keys or list(m)):
  if m[key]!=row[key]:raise AssertionError((key,m[key],row[key]))
 if 'before_hash' in row:assert c.raster_hash(a)==row['before_hash'] and c.raster_hash(b)==row['after_hash']
 return len(keys or m)

def minimal_again(sets):
 out=[]
 for subset in sets:
  if all(not(set(other).issubset(subset) and len(other)<len(subset)) for other in sets):out.append(subset)
 return sorted(out,key=lambda s:(len(s),s))

def main():
 start=time.perf_counter();complete=read(OUT/'results/COMPLETE.json');assert complete['status']=='two_event_source_available_QA_complete'
 for n,h in complete['source_hashes'].items():assert c.file_sha(ROOT/'code'/n)==h
 for n,h in complete['results_sha256'].items():assert c.file_sha(OUT/n)==h
 c.verify_inputs();counts={'all_glyph_comparisons_replayed':0,'pixel_metrics_recomputed':0,'text_comparisons_replayed':0,'text_subset_replays':0,'malayalam_capture_replays':0,'malayalam_subset_replays':0,'control_replays':0,'minimal_subset_sets_checked':0}
 before=(c.PRIVATE/'urdu_before.ttf').read_bytes();after=(c.PRIVATE/'urdu_after.ttf').read_bytes();a=c.face(before);b=c.face(after)
 digest=hashlib.sha256();records=[];observed={}
 with gzip.open(OUT/'results/urdu_all_glyphs.jsonl.gz','rt') as f:
  for line in f:
   digest.update(line.encode());r=json.loads(line);x=independent_raster(a,r['gid'],r['ppem'],r['hinted']);y=independent_raster(b,r['gid'],r['ppem'],r['hinted'])
   counts['pixel_metrics_recomputed']+=checked(x,y,r);counts['all_glyph_comparisons_replayed']+=1
   key=(r['ppem'],r['hinted']);observed.setdefault(key,[])
   if r['changed_pixels_gt1']:observed[key].append(r['gid'])
 assert digest.hexdigest()==complete['urdu']['all_glyph_uncompressed_digest']
 assert counts['all_glyph_comparisons_replayed']==1141*6*2
 for group in complete['urdu']['glyph_scan']:assert observed[(group['ppem'],group['hinted'])]==group['visible_changed_gids_gt1']
 print('VERIFIED_ALL_URDU_GLYPHS',counts['all_glyph_comparisons_replayed'],flush=True)
 # Independently form reverse dependencies and verify original changed records propagate exactly.
 f0=c.tt(before);f1=c.tt(after);raw0=study.raw_glyphs(f0);raw1=study.raw_glyphs(f1);changed=[i for i in range(len(raw0)) if raw0[i]!=raw1[i]]
 assert changed==complete['urdu']['direct_glyph_changes'];impacted=set(changed)
 while True:
  extra={i for i,name in enumerate(f1.getGlyphOrder()) if f1['glyf'][name].isComposite() and any(f1.getGlyphID(x.glyphName) in impacted for x in f1['glyf'][name].components)}
  if extra<=impacted:break
  impacted|=extra
 assert sorted(impacted)==complete['urdu']['dependency_affected_glyphs']
 for row in read(OUT/'results/urdu_texts.json'):
  x,s0=c.render_text(before,row['text'],row['ppem'],row['hinted']);y,s1=c.render_text(after,row['text'],row['ppem'],row['hinted'])
  assert s0==s1;assert [s['gid'] for s in s1]==row['shaped_gids'];counts['pixel_metrics_recomputed']+=checked(x,y,row);counts['text_comparisons_replayed']+=1
 variants={tuple(g):c.swap_glyphs(before,after,g) for r in read(OUT/'results/urdu_swap_replay.json') for g in [x['replacement_gids'] for x in r['traces']]}
 for row in read(OUT/'results/urdu_swap_replay.json'):
  target,_=c.render_text(after,row['text'],row['ppem'],False);matches=[]
  for trace in row['traces']:
   image,_=c.render_text(variants[tuple(trace['replacement_gids'])],row['text'],row['ppem'],False);m=independent_metrics(image,target)
   assert c.raster_hash(image)==trace['hash'];assert m['squared_error']==trace['sse'] and m['max_gray_error']==trace['pixel_error']
   if m['bitwise_image_equal'] and image['advance_26_6']==target['advance_26_6']:matches.append(trace['replacement_gids'])
   counts['text_subset_replays']+=1
  assert matches==row['matching_subsets'];assert minimal_again(matches)==row['inclusion_minimal_subsets'];counts['minimal_subset_sets_checked']+=1
 for row in read(OUT/'results/urdu_controls.json'):
  data=study.control_font(after,row['gid'],row['kind']);x=independent_raster(c.face(after),row['gid'],row['ppem']);y=independent_raster(c.face(data),row['gid'],row['ppem'])
  counts['pixel_metrics_recomputed']+=checked(x,y,row);counts['control_replays']+=1
 print('VERIFIED_URDU_TEXT_AND_REPLAY',flush=True)
 g0=GSFont(str(c.PRIVATE/'malayalam_before.glyphs'));g1=GSFont(str(c.PRIVATE/'malayalam_after.glyphs'));refs={};fonts={}
 for row in read(OUT/'results/malayalam_sources.json'):
  old=c.layer_record(g0.glyphs[row['glyph']].layers[row['master_id']]);new=c.layer_record(g1.glyphs[row['glyph']].layers[row['master_id']]);a0=[x for cc in old['contours'] for x in cc];a1=[x for cc in new['contours'] for x in cc]
  edits=[j for j,(u,v) in enumerate(zip(a0,a1)) if (u['x'],u['y'])!=(v['x'],v['y'])]
  assert edits==row['coordinate_changed_nodes'];assert all(u['type']==v['type'] for u,v in zip(a0,a1));refs[row['master_id']]=(old,new,edits);fonts[row['master_id']]=(c.compile_layer(old),c.compile_layer(new))
 for row in read(OUT/'results/malayalam_visual.json'):
  x,y=[independent_raster(c.face(data),1,row['ppem'],False,(.125,.375)) for data in fonts[row['master_id']]]
  counts['pixel_metrics_recomputed']+=checked(x,y,row);counts['malayalam_capture_replays']+=2
 for row in read(OUT/'results/malayalam_swap_replay.json'):
  old,new,edits=refs[row['master_id']];nn=[x for cc in new['contours'] for x in cc];target=independent_raster(c.face(fonts[row['master_id']][1]),1,row['ppem'],False,(.125,.375));matches=[]
  for trace in row['traces']:
   candidate=c.copy.deepcopy(old);nodes=[x for cc in candidate['contours'] for x in cc]
   for j in trace['replaced_node_indices']:nodes[j]['x']=nn[j]['x'];nodes[j]['y']=nn[j]['y']
   p=independent_raster(c.face(c.compile_layer(candidate)),1,row['ppem'],False,(.125,.375));m=independent_metrics(p,target)
   assert c.raster_hash(p)==trace['predicted_hash'] and m['squared_error']==trace['sse'] and m['max_gray_error']==trace['max_gray_error']
   if m['bitwise_image_equal'] and p['advance_26_6']==target['advance_26_6']:matches.append(trace['replaced_node_indices'])
   counts['malayalam_subset_replays']+=1
  assert matches==row['matching_subsets'];assert minimal_again(matches)==row['inclusion_minimal_subsets'];counts['minimal_subset_sets_checked']+=1
 for row in read(OUT/'results/malayalam_controls.json'):
  old,new,edits=refs[row['master_id']];candidate=c.copy.deepcopy(new)
  if row['kind']=='smooth_flags_only':
   for contour in candidate['contours']:
    for node in contour:node['smooth']=not node['smooth']
  elif row['kind']=='cyclic_start':candidate['contours']=[path[1:]+path[:1] for path in candidate['contours']]
  elif row['kind']=='declared_intentional_translation':
   for contour in candidate['contours']:
    for node in contour:node['x']+=8
  else:raise ValueError('Unexpected control')
  x=independent_raster(c.face(fonts[row['master_id']][1]),1,row['ppem'],False,(.125,.375));y=independent_raster(c.face(c.compile_layer(candidate)),1,row['ppem'],False,(.125,.375));counts['pixel_metrics_recomputed']+=checked(x,y,row);counts['control_replays']+=1
 for n,h in complete['results_sha256'].items():assert c.file_sha(OUT/n)==h
 c.verify_inputs();audit={'status':'two_event_QA_saved_outputs_replayed_and_checked','verified_utc':c.utc(),'counts':counts,'input_artifacts_verified':4,'input_artifacts_unchanged':True,'frozen_scientific_sources':len(complete['source_hashes']),
  'independent_bitmap_byte_extraction':True,'independent_integer_pixel_arithmetic':True,'font_renderer_and_compiler_reused':True,'new_training':False,'event_count':2,
  'seconds':time.perf_counter()-start,'completion_sha256':c.file_sha(OUT/'results/COMPLETE.json'),'audit_sha256':c.file_sha(__file__),
  'limits':['two known maintainer-described repair events, not independent blinded benchmark','Urdu original full font binaries; Malayalam standalone affected-master CFF reconstruction','known acquisition only; not every production rasterizer','source-swap evidence is conditional on actual observed before/after changes','no independent expert defect labels or measured human time saving','first native crash not causally diagnosed; scientific settings unchanged during repeat','timings not independently repeated']}
 c.put(OUT/'results/VERIFIED.json',audit);print('QA_VERIFIED',json.dumps(audit),flush=True)
if __name__=='__main__':main()
