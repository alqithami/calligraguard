#!/usr/bin/env python3
"""Prepare source-available comparison inputs; never redistribute font binaries.
All configurations are development comparisons on two already-inspected repair events.
"""
from pathlib import Path
import copy,hashlib,json,sys,time,subprocess
import glyphsLib
from fontTools.ttLib import TTFont
import common
ROOT=Path(__file__).resolve().parent;PRIVATE=ROOT/'private_inputs';FONTS=ROOT/'private_comparison_fonts'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def dump(p,x):Path(p).write_text(json.dumps(x,indent=2,allow_nan=False)+'\n')
def main():
 FONTS.mkdir(exist_ok=False)
 for n,d in common.EXPECTED.items():assert sha(PRIVATE/n)==d
 specs=[]
 def pair(cid,a,b,kind,event,scope):
  specs.append({'id':cid,'before':str(a),'after':str(b),'before_sha256':sha(a),'after_sha256':sha(b),'kind':kind,'event':event,'scope':scope})
 u0=PRIVATE/'urdu_before.ttf';u1=PRIVATE/'urdu_after.ttf'
 pair('urdu_historical',u0,u1,'maintainer_described_repair','urdu_contour_direction','original complete pinned font binaries')
 pair('urdu_exact_replay',u1,u1,'exact_replay','urdu_contour_direction','same binary control')
 before=glyphsLib.GSFont(str(PRIVATE/'malayalam_before.glyphs'));after=glyphsLib.GSFont(str(PRIVATE/'malayalam_after.glyphs'))
 assert before.upm==after.upm==1000
 for i,master in enumerate(after.masters,1):
  a=common.layer_record(before.glyphs['iivowelsignmlym'].layers[master.id]);b=common.layer_record(after.glyphs['iivowelsignmlym'].layers[master.id])
  p0=FONTS/f'malayalam_{i}_before.otf';p1=FONTS/f'malayalam_{i}_after.otf';p0.write_bytes(common.compile_layer(a));p1.write_bytes(common.compile_layer(b))
  scope='standalone unhinted master reconstruction; ASCII A maps to observed glyph; not official Malayalam release/shaping'
  pair(f'malayalam_master_{i}',p0,p1,'maintainer_described_repair','malayalam_issue25',scope)
  if i==1:
   pair('malayalam_exact_replay',p1,p1,'exact_replay','malayalam_issue25',scope)
   smooth=copy.deepcopy(b)
   for c in smooth['contours']:
    for n in c:n['smooth']=not n['smooth']
   cyc=copy.deepcopy(b)
   cyc['contours']=[c[1:]+c[:1] for c in cyc['contours']]
   shifted=copy.deepcopy(b)
   for c in shifted['contours']:
    for n in c:n['x']+=8
   for label,rec,kind in [('smooth_metadata',smooth,'representation_control'),('cyclic_start',cyc,'representation_control'),('declared_translation',shifted,'synthetic_declared_intent')]:
    dest=FONTS/('malayalam_'+label+'.otf');dest.write_bytes(common.compile_layer(rec));pair('malayalam_'+label,p1,dest,kind,'malayalam_issue25',scope)
 # Use the same exact controlled glyph edits as the prior source-available QA stage.
 import run_study
 for kind in ['metadata_only','cyclic_point_start','all_contours_reversed','declared_intentional_translation']:
  dest=FONTS/('urdu_'+kind+'.ttf');dest.write_bytes(run_study.control_font(u1.read_bytes(),16,kind))
  pair('urdu_'+kind,u1,dest,'synthetic_declared_intent' if 'translation' in kind else 'representation_control','urdu_contour_direction','controlled modification of original full binary, native glyph16')
 dump(ROOT/'PRIVATE_PAIR_MANIFEST.json',specs)
 safe=[{k:v for k,v in x.items() if k not in ['before','after']} for x in specs]
 dump(ROOT/'PAIR_MANIFEST_PUBLIC.json',safe)
 version=subprocess.check_output([str(ROOT/'.venv311/bin/diffenator3'),'--version'],text=True).strip()
 freeze=subprocess.check_output([str(ROOT/'.venv311/bin/python'),'-m','pip','freeze'],text=True);(ROOT/'environment.freeze.txt').write_text(freeze)
 dump(ROOT/'EXTERNAL_PROTOCOL.json',{'status':'fixed_before_results','tool':version,'official_package':'diffenator3==1.1.4','pairs':len(specs),'pair_kinds':{k:sum(x['kind']==k for x in specs) for k in sorted({x['kind'] for x in specs})},'command_options':['--json','--pretty','--max-changes','100000','--jobs','2'],
 'settings':'official defaults for tables, kerns, glyphs, words and languages; no custom threshold or size override exposed by installed CLI','timeout_seconds_per_pair':240,'parallel_pair_workers':2,
 'comparison_scope':'difference reporting and source-impact coverage, not defect-intent accuracy; renderer/sampling differ from FreeType enumeration','known_events':2,'new_expert_labels':False,'new_neural_fits':0,'human_review_status':'not performed','original_code_hashes':{'common.py':sha(ROOT/'common.py'),'run_study.py':sha(ROOT/'run_study.py')},'runner_input_manifest_sha256':sha(ROOT/'PAIR_MANIFEST_PUBLIC.json')})
 print('EXTERNAL_PAIRS_PREPARED',len(specs),version,flush=True)
if __name__=='__main__':main()
