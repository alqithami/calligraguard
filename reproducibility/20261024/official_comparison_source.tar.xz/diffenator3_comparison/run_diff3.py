#!/usr/bin/env python3
"""Execute unmodified official Diffenator3 on the fixed source-available pair set."""
from pathlib import Path
import concurrent.futures,datetime,hashlib,json,subprocess,time,traceback
ROOT=Path(__file__).resolve().parent

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def put(p,j):
 p=Path(p);t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(j,indent=2,allow_nan=False)+'\n');t.replace(p)
def run(pair):
 out=ROOT/'official_reports';out.mkdir(exist_ok=True);name=pair['id'];receipt=out/(name+'.receipt.json')
 if receipt.exists():
  r=json.loads(receipt.read_text())
  if all(sha(out/f)==h for f,h in r['output_sha256'].items()):return r
  raise ValueError('Existing output hash mismatch '+name)
 assert sha(pair['before'])==pair['before_sha256'] and sha(pair['after'])==pair['after_sha256']
 cmd=[str(ROOT/'.venv311/bin/diffenator3'),'--json','--pretty','--max-changes','100000','--jobs','2',pair['before'],pair['after']]
 target=out/(name+'.json');errors=out/(name+'.stderr.txt');start=time.perf_counter();rc=None;timed_out=False
 with target.open('wb') as f,errors.open('wb') as g:
  try:rc=subprocess.run(cmd,stdout=f,stderr=g,timeout=240,check=False,cwd=ROOT).returncode
  except subprocess.TimeoutExpired:timed_out=True
 parsed=None;error=None
 try:parsed=json.loads(target.read_text())
 except Exception as e:error=str(e)
 r={'id':name,'kind':pair['kind'],'event':pair['event'],'scope':pair['scope'],'exit_code':rc,'timed_out':timed_out,'json_parsed':parsed is not None,
    'parse_error':error,'seconds':time.perf_counter()-start,'stdout_bytes':target.stat().st_size,'json_top_level':list(parsed) if isinstance(parsed,dict) else type(parsed).__name__,
    'input_sha256':{'before':pair['before_sha256'],'after':pair['after_sha256']},'output_sha256':{target.name:sha(target),errors.name:sha(errors)},
    'command':['diffenator3','--json','--pretty','--max-changes','100000','--jobs','2','<private_before_font>','<private_after_font>']}
 put(receipt,r);print('DIFF3_CASE',name,'exit',rc,'json',r['json_parsed'],'seconds',round(r['seconds'],2),flush=True);return r

def main():
 if (ROOT/'EXTERNAL_EXECUTION_COMPLETE.json').exists():raise FileExistsError('External comparison already completed')
 pairs=json.loads((ROOT/'PRIVATE_PAIR_MANIFEST.json').read_text());sources={n:sha(ROOT/n) for n in ['prepare_diff3.py','run_diff3.py','common.py','run_study.py','EXTERNAL_PROTOCOL.json']}
 put(ROOT/'EXTERNAL_RUN_LOCK.json',{'created_utc':now(),'sources_sha256':sources,'manifest_sha256':sha(ROOT/'PRIVATE_PAIR_MANIFEST.json')})
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:records=list(pool.map(run,pairs))
 assert sources=={n:sha(ROOT/n) for n in sources}
 put(ROOT/'EXTERNAL_EXECUTION_COMPLETE.json',{'status':'all_configured_external_invocations_finished','completed_utc':now(),'cases':len(records),'successful_json_zero_exit':sum(r['json_parsed'] and r['exit_code']==0 for r in records),'failed_or_timed_out':sum(not r['json_parsed'] or r['exit_code']!=0 for r in records),'records':records,'sources_sha256':sources,'not_a_defect_classifier_evaluation':True})
 print('DIFFENATOR3_EXECUTION_COMPLETE',len(records),flush=True)
if __name__=='__main__':
 try:main()
 except Exception as e:
  put(ROOT/'EXTERNAL_FAILED.json',{'utc':now(),'error':str(e),'traceback':traceback.format_exc()});raise
